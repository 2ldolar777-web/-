package com.example.di

import android.content.Context
import androidx.room.Room
import com.example.automation.SaqrBridge
import com.example.automation.SaqrProcessOptimizer
import com.example.automation.SecureCommandController
import com.example.core.CommandProcessor
import com.example.core.SaqrAiCore
import com.example.core.TokenBudgetManager
import com.example.data.FeedbackDao
import com.example.data.SaqrDatabase

class AppModule(context: Context) {

    val saqrDatabase: SaqrDatabase by lazy {
        Room.databaseBuilder(
            context,
            SaqrDatabase::class.java,
            "saqr_os_core_db"
        ).build()
    }

    val feedbackDao: FeedbackDao by lazy {
        saqrDatabase.feedbackDao()
    }

    val privacyVaultRepository: com.example.core.PrivacyVaultRepository by lazy {
        com.example.core.PrivacyVaultRepository(feedbackDao)
    }

    val prefetchEngine: com.example.core.SaqrPrefetchEngine by lazy {
        com.example.core.SaqrPrefetchEngine()
    }

    val visualContextAnalyzer: com.example.core.SaqrVisualContextAnalyzer by lazy {
        com.example.core.SaqrVisualContextAnalyzer()
    }

    val thermalGovernor: com.example.core.SaqrThermalGovernor by lazy {
        com.example.core.SaqrThermalGovernor()
    }

    val notificationTunnel: com.example.core.SaqrNotificationTunnel by lazy {
        com.example.core.SaqrNotificationTunnel()
    }

    val sensorEventBus: com.example.core.SaqrSensorEventBus by lazy {
        com.example.core.SaqrSensorEventBus()
    }

    val accessibilityHookService: com.example.core.SaqrAccessibilityHookService by lazy {
        com.example.core.SaqrAccessibilityHookService()
    }

    val aiCore: SaqrAiCore by lazy { SaqrAiCore(context) }
    val localAiManager: com.example.core.LocalAiManager by lazy { com.example.core.LocalAiManager(context) }
    val systemSettingsManager: com.example.automation.SystemSettingsManager by lazy { com.example.automation.SystemSettingsManager(context) }
    val offlineSpeechRecognizer: com.example.speech.OfflineSpeechRecognizer by lazy { com.example.speech.OfflineSpeechRecognizer(context) }
    val tokenBudgetManager: TokenBudgetManager by lazy { TokenBudgetManager() }
    val processOptimizer: SaqrProcessOptimizer by lazy { SaqrProcessOptimizer(context) }
    val saqrBridge: SaqrBridge by lazy { SaqrBridge(context, processOptimizer) }
    val secureController: SecureCommandController by lazy { SecureCommandController(context) }
    val commandProcessor: CommandProcessor by lazy { CommandProcessor(saqrBridge) }
}

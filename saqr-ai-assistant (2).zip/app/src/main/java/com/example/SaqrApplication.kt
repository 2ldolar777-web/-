package com.example

import android.app.Application
import com.example.di.AppModule

class SaqrApplication : Application() {
    lateinit var appModule: AppModule

    override fun onCreate() {
        super.onCreate()
        appModule = AppModule(this)
    }
}

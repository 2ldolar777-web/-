package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SaqrBackground = Color(0xFF0A0A0A)
val SaqrSurface = Color(0xFF141414)
val SaqrNeonBlue = Color(0xFF00E5FF)
val SaqrNeonRed = Color(0xFFFF1744)
val SaqrTextPrimary = Color(0xFFFFFFFF)
val SaqrTextSecondary = Color(0xFFB0B0B0)

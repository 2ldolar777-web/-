package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val SaqrDarkColorScheme = darkColorScheme(
    primary = SaqrNeonBlue,
    secondary = SaqrNeonBlue,
    tertiary = SaqrNeonBlue,
    background = SaqrBackground,
    surface = SaqrSurface,
    onPrimary = SaqrBackground,
    onSecondary = SaqrBackground,
    onTertiary = SaqrBackground,
    onBackground = SaqrTextPrimary,
    onSurface = SaqrTextPrimary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force Dark Neon Theme
    dynamicColor: Boolean = false, // Disable dynamic colors to keep Neon Theme
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SaqrDarkColorScheme,
        typography = Typography,
        content = content
    )
}

package com.example.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class OfflineSpeechRecognizer(private val context: Context) {

    private var speechRecognizer: SpeechRecognizer? = null
    
    private val _state = MutableStateFlow<SpeechState>(SpeechState.Idle)
    val state: StateFlow<SpeechState> = _state.asStateFlow()

    init {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _state.value = SpeechState.Listening
                    }

                    override fun onBeginningOfSpeech() {
                        _state.value = SpeechState.Processing
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        // Can be used for UI visualizer if needed
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        _state.value = SpeechState.Processing
                    }

                    override fun onError(error: Int) {
                        val errorMessage = when (error) {
                            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                            SpeechRecognizer.ERROR_CLIENT -> "Client-side error"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Insufficient permissions"
                            SpeechRecognizer.ERROR_NETWORK -> "Network error"
                            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
                            SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized"
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer is busy"
                            SpeechRecognizer.ERROR_SERVER -> "Server error"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech input timeout"
                            else -> "Unknown error"
                        }
                        _state.value = SpeechState.Error(errorMessage)
                        Log.e("OfflineSpeechRecognizer", "Speech Error: $errorMessage ($error)")
                    }

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            val recognizedText = matches[0]
                            _state.value = SpeechState.Success(recognizedText)
                        } else {
                            _state.value = SpeechState.Error("No text recognized")
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {}

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        } else {
            _state.value = SpeechState.NotAvailable
            Log.e("OfflineSpeechRecognizer", "Speech recognition not available on this device.")
        }
    }

    /**
     * Starts listening for voice input offline.
     */
    fun startListening() {
        val recognizer = speechRecognizer
        if (recognizer == null) {
            _state.value = SpeechState.NotAvailable
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().language)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            // Force offline execution to ensure zero cloud dependence
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }

        try {
            recognizer.startListening(intent)
            _state.value = SpeechState.Listening
        } catch (e: Exception) {
            _state.value = SpeechState.Error(e.localizedMessage ?: "Failed to start listening")
        }
    }

    /**
     * Cancels the active speech recognition session.
     */
    fun stopListening() {
        speechRecognizer?.stopListening()
        _state.value = SpeechState.Idle
    }

    /**
     * Destroys the recognizer resources when not needed.
     */
    fun destroy() {
        speechRecognizer?.destroy()
        speechRecognizer = null
    }
}

sealed class SpeechState {
    object Idle : SpeechState()
    object Listening : SpeechState()
    object Processing : SpeechState()
    data class Success(val text: String) : SpeechState()
    data class Error(val message: String) : SpeechState()
    object NotAvailable : SpeechState()
}

package com.example.automation

import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import android.util.Log

class SystemSettingsManager(private val context: Context) {

    /**
     * Checks if the application has been granted the WRITE_SECURE_SETTINGS permission.
     */
    fun hasSecureSettingsPermission(): Boolean {
        return context.checkSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Modifies a Secure Setting if permission is granted.
     * Returns true if successful, false otherwise.
     */
    fun writeSecureSetting(key: String, value: String): Boolean {
        return if (hasSecureSettingsPermission()) {
            try {
                Settings.Secure.putString(context.contentResolver, key, value)
                Log.d("SystemSettingsManager", "Successfully wrote $key = $value to Secure Settings.")
                true
            } catch (e: Exception) {
                Log.e("SystemSettingsManager", "Error writing to Secure Settings", e)
                false
            }
        } else {
            Log.e("SystemSettingsManager", "WRITE_SECURE_SETTINGS permission is NOT granted.")
            false
        }
    }

    /**
     * Returns the exact ADB instruction to copy/paste to grant the required permission.
     */
    fun getAdbCommandInstruction(): String {
        val packageName = context.packageName
        return "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS"
    }
}

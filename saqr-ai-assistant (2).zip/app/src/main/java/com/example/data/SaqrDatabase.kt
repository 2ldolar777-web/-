package com.example.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Fts4
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "feedback_logs")
data class FeedbackLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val prompt: String,
    val modelOutput: String,
    val isSatisfied: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

@Fts4(contentEntity = FeedbackLog::class)
@Entity(tableName = "feedback_logs_fts")
data class FeedbackLogFts(
    val prompt: String,
    val modelOutput: String
)

@Dao
interface FeedbackDao {
    @Insert
    suspend fun insertFeedback(feedbackLog: FeedbackLog)

    @Query("SELECT * FROM feedback_logs ORDER BY timestamp DESC LIMIT 100")
    fun getRecentFeedbacks(): Flow<List<FeedbackLog>>
    
    @Query("SELECT * FROM feedback_logs JOIN feedback_logs_fts ON feedback_logs.rowid = feedback_logs_fts.rowid WHERE feedback_logs_fts MATCH :query")
    suspend fun searchFeedback(query: String): List<FeedbackLog>
}

@Database(entities = [FeedbackLog::class, FeedbackLogFts::class], version = 1, exportSchema = false)
abstract class SaqrDatabase : RoomDatabase() {
    abstract fun feedbackDao(): FeedbackDao
}

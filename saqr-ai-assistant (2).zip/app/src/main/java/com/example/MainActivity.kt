package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.presentation.SaqrScreen
import com.example.presentation.SaqrViewModel
import com.example.presentation.SaqrViewModelFactory
import com.example.presentation.ChatViewModel
import com.example.presentation.ChatViewModelFactory
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    
    val appModule = (application as SaqrApplication).appModule
    val factory = SaqrViewModelFactory(
        appModule.localAiManager,
        appModule.commandProcessor,
        appModule.tokenBudgetManager,
        appModule.systemSettingsManager,
        appModule.privacyVaultRepository,
        appModule.prefetchEngine,
        appModule.visualContextAnalyzer,
        appModule.thermalGovernor,
        appModule.notificationTunnel,
        appModule.sensorEventBus,
        appModule.accessibilityHookService,
        appModule.offlineSpeechRecognizer
    )
    val viewModel: SaqrViewModel by viewModels { factory }

    val chatFactory = ChatViewModelFactory(
        appModule.localAiManager,
        appModule.saqrBridge,
        appModule.systemSettingsManager,
        appModule.tokenBudgetManager,
        appModule.privacyVaultRepository
    )
    val chatViewModel: ChatViewModel by viewModels { chatFactory }

    setContent {
      MyApplicationTheme {
        SaqrScreen(
            viewModel = viewModel,
            chatViewModel = chatViewModel
        )
      }
    }
  }
}

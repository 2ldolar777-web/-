package com.example.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import com.example.automation.SaqrBridge
import com.example.automation.SystemSettingsManager
import com.example.core.CommandParser
import com.example.core.LocalAiManager
import com.example.core.PrivacyVaultRepository
import com.example.core.TokenBudgetManager
import com.example.core.GeminiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.util.UUID

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val executedCommand: String? = null,
    val attachedImageBytes: ByteArray? = null
)

data class ChatUiState(
    val messages: List<ChatMessage> = listOf(
        ChatMessage(
            text = "يا مرحب بيك يا أبو صقر! منورني دايماً! 😂 أنا صقر (Saqr AI OS Core) جاهز لأي أتمتة أو تحكم تطلبه مني بالعامية المصرية. جرب الأزرار السريعة فوق أو اكتبلي أي حاجة!",
            isUser = false
        )
    ),
    val isProcessing: Boolean = false,
    val error: String? = null,
    val isGeminiMode: Boolean = true, // Default to true for premium experience
    val attachedImageBytes: ByteArray? = null,
    val attachedImageName: String? = null
)

class ChatViewModel(
    private val localAiManager: LocalAiManager,
    private val saqrBridge: SaqrBridge,
    private val systemSettingsManager: SystemSettingsManager,
    private val tokenBudgetManager: TokenBudgetManager,
    private val privacyVaultRepository: PrivacyVaultRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    fun toggleAiMode() {
        _uiState.value = _uiState.value.copy(isGeminiMode = !_uiState.value.isGeminiMode)
    }

    fun attachMockImage(type: String) {
        val (name, bytes) = when (type) {
            "WIFI_ERROR" -> "صورة_خطأ_الواي_فاي.jpg" to createMockScreenshot("WIFI_ERROR")
            "RAM_FULL" -> "صورة_ذاكرة_ممتلئة.jpg" to createMockScreenshot("RAM_FULL")
            "OVERHEATING" -> "صورة_حرارة_مرتفعة.jpg" to createMockScreenshot("OVERHEATING")
            else -> "صورة_معاينة.jpg" to createMockScreenshot("WIFI_ERROR")
        }
        _uiState.value = _uiState.value.copy(
            attachedImageBytes = bytes,
            attachedImageName = name
        )
    }

    fun attachGalleryImage(bytes: ByteArray, name: String) {
        _uiState.value = _uiState.value.copy(
            attachedImageBytes = bytes,
            attachedImageName = name
        )
    }

    fun clearAttachedImage() {
        _uiState.value = _uiState.value.copy(
            attachedImageBytes = null,
            attachedImageName = null
        )
    }

    private fun createMockScreenshot(issueType: String): ByteArray {
        val bitmap = Bitmap.createBitmap(400, 300, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint()
        
        // Draw background
        paint.color = AndroidColor.parseColor("#050505")
        canvas.drawRect(0f, 0f, 400f, 300f, paint)
        
        // Draw cyberpunk grid/borders
        paint.color = AndroidColor.parseColor("#00F0FF") // Neon Blue
        paint.strokeWidth = 4f
        paint.style = Paint.Style.STROKE
        canvas.drawRect(10f, 10f, 390f, 290f, paint)
        
        paint.style = Paint.Style.FILL
        // Title
        paint.textSize = 20f
        paint.isFakeBoldText = true
        canvas.drawText("SAQR DIAGNOSTICS v1.0", 30f, 45f, paint)
        
        // Draw issue specific details
        paint.color = AndroidColor.WHITE
        paint.textSize = 14f
        paint.isFakeBoldText = false
        
        when (issueType) {
            "WIFI_ERROR" -> {
                paint.color = AndroidColor.parseColor("#FF0055") // Neon Red
                canvas.drawText("STATUS: CONNECTION_FAILURE", 30f, 90f, paint)
                paint.color = AndroidColor.GRAY
                canvas.drawText("IP Address: null", 30f, 120f, paint)
                canvas.drawText("SSID: SAQR_HOTSPOT_5G", 30f, 140f, paint)
                canvas.drawText("Signal Strength: 0% (Offline)", 30f, 160f, paint)
                
                paint.color = AndroidColor.parseColor("#FF0055")
                canvas.drawText("[ ! ] WIFI HARDWARE OFF", 30f, 210f, paint)
            }
            "RAM_FULL" -> {
                paint.color = AndroidColor.parseColor("#FF0055")
                canvas.drawText("STATUS: MEMORY_WARNING", 30f, 90f, paint)
                paint.color = AndroidColor.GRAY
                canvas.drawText("Total System RAM: 4.00 GB", 30f, 120f, paint)
                canvas.drawText("Active App Footprint: 3.82 GB", 30f, 140f, paint)
                canvas.drawText("Available Buffer: 180 MB (Low)", 30f, 160f, paint)
                
                paint.color = AndroidColor.parseColor("#FF0055")
                canvas.drawText("[ ! ] CACHE THROTTLING ACTIVE", 30f, 210f, paint)
            }
            "OVERHEATING" -> {
                paint.color = AndroidColor.parseColor("#FF0055")
                canvas.drawText("STATUS: THERMAL_CRITICAL", 30f, 90f, paint)
                paint.color = AndroidColor.GRAY
                canvas.drawText("Core Temperature: 48.5 C", 30f, 120f, paint)
                canvas.drawText("Battery Temp: 45.0 C (Hot)", 30f, 140f, paint)
                canvas.drawText("CPU Governor: Performance (Locked)", 30f, 160f, paint)
                
                paint.color = AndroidColor.parseColor("#FF0055")
                canvas.drawText("[ ! ] THERMAL THROTTLING INDUCED", 30f, 210f, paint)
            }
        }
        
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
        return stream.toByteArray()
    }

    fun processInput(message: String) {
        if (message.isBlank()) return

        // Extract any attached image from the current state
        val imageToUpload = _uiState.value.attachedImageBytes
        
        // 1. Add the user's message to the conversation (including any image bytes)
        val userMsg = ChatMessage(text = message, isUser = true, attachedImageBytes = imageToUpload)
        _uiState.value = _uiState.value.copy(
            messages = _uiState.value.messages + userMsg,
            isProcessing = true,
            error = null,
            attachedImageBytes = null, // Clear composer slots immediately
            attachedImageName = null
        )

        viewModelScope.launch {
            // Check if the user's input explicitly contains an embedded CMD command (e.g., from quick chips or direct typing)
            val userParsed = CommandParser.parseMessage(message)
            
            // Clean user text displayed in the bubble to hide the CMD tag if present
            if (userParsed.commands.isNotEmpty()) {
                val updatedMessages = _uiState.value.messages.map { 
                    if (it.id == userMsg.id) it.copy(text = userParsed.cleanText) else it 
                }
                _uiState.value = _uiState.value.copy(messages = updatedMessages)

                // Execute command immediately in the background
                for (cmd in userParsed.commands) {
                    saqrBridge.executeSystemCommand(cmd)
                }

                // Typewriter streamed Egyptian colloquial confirmation
                streamAssistantResponse("تمام يا أبو صقر! 😂 تم تنفيذ الأمر المطلوب فوراً في الخلفية ومراعاة سلامة السيستم.", executedCommand = userParsed.commands.firstOrNull())
                return@launch
            }

            // Otherwise, scan user's message text for semantic keywords to automate actions instantly
            val semanticCmd = detectSemanticCommand(message)
            if (semanticCmd != null) {
                saqrBridge.executeSystemCommand(semanticCmd)
                val friendlyConfirmation = when (semanticCmd) {
                    "WIFI_OFF" -> "حاضر يا أبو صقر! 😂 قفلتلك الواي فاي فوراً عشان نوفر البطارية."
                    "WIFI_ON" -> "من عيوني يا غالي! 😂 شغلتلك الواي فاي عشان تفضل أونلاين على طول."
                    "OPTIMIZE_RAM" -> "أمرك يا أبو صقر! 😂 فضيتلك الرامات حالا وشغلت SmartHibernate عشان الموبايل يطير."
                    "BLUETOOTH_OFF" -> "تمام يا غالي! 😂 قفلتلك البلوتوث عشان نحافظ على شحن الجهاز."
                    "POWER_SAVE_ON" -> "من عينيا يا أبو صقر! 😂 فعلتلك وضع توفير الطاقة الأقصى فوراً."
                    else -> "تمام يا أبو صقر! 😂 تم تنفيذ طلبك بسرعة طلقة."
                }
                streamAssistantResponse(friendlyConfirmation, executedCommand = semanticCmd)
                return@launch
            }

            // --- Option A: Gemini Multimodal Mode (Premium AI Features) ---
            if (_uiState.value.isGeminiMode) {
                try {
                    val responseText = GeminiManager.generateResponse(message, imageToUpload)
                    
                    val finalParsed = CommandParser.parseMessage(responseText)
                    if (finalParsed.commands.isNotEmpty()) {
                        for (cmd in finalParsed.commands) {
                            saqrBridge.executeSystemCommand(cmd)
                        }
                    }

                    streamAssistantResponse(responseText, executedCommand = finalParsed.commands.firstOrNull())
                    privacyVaultRepository.saveFeedback(message, responseText, true)
                } catch (e: Exception) {
                    _uiState.value = _uiState.value.copy(
                        messages = _uiState.value.messages + ChatMessage(
                            text = "حصل مشكلة في الاتصال بمخ صقر الذكي يا أبو صقر: ${e.localizedMessage} 😂",
                            isUser = false
                        ),
                        isProcessing = false
                    )
                }
                return@launch
            }

            // --- Option B: Native On-Device Local Model (Phi-3.5) ---
            if (!tokenBudgetManager.checkBudget()) {
                _uiState.value = _uiState.value.copy(
                    error = "بروتوكول الأمان: تم تجاوز حد الرامات المسموح به. يرجى تفعيل SmartHibernate أولاً.",
                    isProcessing = false
                )
                return@launch
            }

            try {
                var accumulatedText = ""
                val botMessageId = UUID.randomUUID().toString()
                
                // Add an empty bot message structure to start streaming character updates into
                val initialBotMsg = ChatMessage(id = botMessageId, text = "", isUser = false)
                _uiState.value = _uiState.value.copy(messages = _uiState.value.messages + initialBotMsg)

                // Wraps user prompt in authentic Egyptian slang system prompt
                val systemIntercepted = SaqrViewModel.PersonaInterceptor.intercept(message)
                
                localAiManager.generateStreamingResponse(systemIntercepted).collect { chunk ->
                    accumulatedText += chunk
                    
                    // Parse text dynamically as it's streamed to filter out any raw [CMD:...] commands from the user bubble view
                    val parsed = CommandParser.parseMessage(accumulatedText)
                    
                    val updatedMessages = _uiState.value.messages.map { msg ->
                        if (msg.id == botMessageId) {
                            msg.copy(text = parsed.cleanText)
                        } else msg
                    }
                    _uiState.value = _uiState.value.copy(messages = updatedMessages)
                }

                // Stream ended. Parse final full response, execute any found command, and save to encrypted vault
                val finalParsed = CommandParser.parseMessage(accumulatedText)
                if (finalParsed.commands.isNotEmpty()) {
                    for (cmd in finalParsed.commands) {
                        saqrBridge.executeSystemCommand(cmd)
                    }
                    
                    // Update final screen message displaying clean text and linking the executed command
                    val updatedMessages = _uiState.value.messages.map { msg ->
                        if (msg.id == botMessageId) {
                            val displayResponseText = if (finalParsed.cleanText.isBlank()) {
                                "حاضر يا أبو صقر! 😂 نفذت الأمر المطلوب حالاً وبدون أي تأخير."
                            } else {
                                finalParsed.cleanText
                            }
                            msg.copy(text = displayResponseText, executedCommand = finalParsed.commands.first())
                        } else msg
                    }
                    _uiState.value = _uiState.value.copy(messages = updatedMessages)
                }

                // Log the interaction securely inside the local encrypted SQLite DB
                privacyVaultRepository.saveFeedback(message, accumulatedText, true)

            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    messages = _uiState.value.messages + ChatMessage(
                        text = "حصل مشكلة يا أبو صقر: ${e.localizedMessage} 😂",
                        isUser = false
                    )
                )
            } finally {
                _uiState.value = _uiState.value.copy(isProcessing = false)
            }
        }
    }

    private fun detectSemanticCommand(input: String): String? {
        val trimmed = input.trim().lowercase()
        return when {
            trimmed.contains("قفل الواي فاي") || trimmed.contains("إغلاق الواي فاي") || trimmed.contains("اطفي الواي فاي") -> "WIFI_OFF"
            trimmed.contains("فتح الواي فاي") || trimmed.contains("شغل الواي فاي") || trimmed.contains("شغلي الواي فاي") -> "WIFI_ON"
            trimmed.contains("تنظيف الرام") || trimmed.contains("فضي الرام") || trimmed.contains("تنضف الرام") || trimmed.contains("تحسين الرام") -> "OPTIMIZE_RAM"
            trimmed.contains("قفل البلوتوث") || trimmed.contains("إغلاق البلوتوث") || trimmed.contains("اطفي البلوتوث") -> "BLUETOOTH_OFF"
            trimmed.contains("شغل البلوتوث") || trimmed.contains("فتح البلوتوث") -> "BLUETOOTH_ON"
            trimmed.contains("توفير الطاقة") || trimmed.contains("وضع توفير الطاقة") || trimmed.contains("شغل توفير الطاقة") -> "POWER_SAVE_ON"
            else -> null
        }
    }

    private suspend fun streamAssistantResponse(fullText: String, executedCommand: String? = null) {
        val botMessageId = UUID.randomUUID().toString()
        val initialMsg = ChatMessage(id = botMessageId, text = "", isUser = false, executedCommand = executedCommand)
        _uiState.value = _uiState.value.copy(messages = _uiState.value.messages + initialMsg)

        var streamedText = ""
        for (char in fullText) {
            streamedText += char
            val updatedMessages = _uiState.value.messages.map { msg ->
                if (msg.id == botMessageId) {
                    msg.copy(text = streamedText)
                } else msg
            }
            _uiState.value = _uiState.value.copy(messages = updatedMessages)
            delay(15) // Fluid, high-fidelity typewriter speed
        }
        _uiState.value = _uiState.value.copy(isProcessing = false)
    }
}

class ChatViewModelFactory(
    private val localAiManager: LocalAiManager,
    private val saqrBridge: SaqrBridge,
    private val systemSettingsManager: SystemSettingsManager,
    private val tokenBudgetManager: TokenBudgetManager,
    private val privacyVaultRepository: PrivacyVaultRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ChatViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ChatViewModel(
                localAiManager,
                saqrBridge,
                systemSettingsManager,
                tokenBudgetManager,
                privacyVaultRepository
            ) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

package com.example.presentation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.neonGlow
import com.example.ui.components.SystemDash
import com.example.ui.theme.SaqrNeonBlue
import com.example.ui.theme.SaqrSurface
import com.example.ui.theme.SaqrNeonRed
import com.example.speech.SpeechState
import kotlinx.coroutines.delay
import java.util.Locale

@Composable
fun MicIcon(tint: Color, modifier: Modifier = Modifier) {
    androidx.compose.foundation.Canvas(modifier = modifier.size(20.dp)) {
        // Draw microphone capsule
        drawRoundRect(
            color = tint,
            topLeft = androidx.compose.ui.geometry.Offset(6.dp.toPx(), 3.dp.toPx()),
            size = androidx.compose.ui.geometry.Size(8.dp.toPx(), 11.dp.toPx()),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx(), 4.dp.toPx()),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
        )
        // Draw microphone stand / u-shape
        drawArc(
            color = tint,
            startAngle = 0f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = androidx.compose.ui.geometry.Offset(3.dp.toPx(), 7.dp.toPx()),
            size = androidx.compose.ui.geometry.Size(14.dp.toPx(), 10.dp.toPx()),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
        )
        // Draw stand stem
        drawLine(
            color = tint,
            start = androidx.compose.ui.geometry.Offset(10.dp.toPx(), 17.dp.toPx()),
            end = androidx.compose.ui.geometry.Offset(10.dp.toPx(), 19.dp.toPx()),
            strokeWidth = 2.dp.toPx()
        )
    }
}

@Composable
fun SaqrScreen(
    viewModel: SaqrViewModel,
    chatViewModel: ChatViewModel
) {
    val uiState by viewModel.uiState.collectAsState()
    var inputText by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf(0) }
    var decryptLogs by remember { mutableStateOf(false) }
    val clipboardManager = LocalClipboardManager.current

    // Background sensory poller trigger
    LaunchedEffect(Unit) {
        while(true) {
            viewModel.simulateSensors()
            delay(4000)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF070707))
                .statusBarsPadding()
        ) {
            // System Status Bar / Header matching Elegant Dark HTML exactly
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "SYSTEM CORE v1.0.8",
                        color = SaqrNeonBlue,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "صقر ",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Light,
                            fontStyle = FontStyle.Italic
                        )
                        Text(
                            text = "SAQR AI",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(SaqrNeonBlue, shape = RoundedCornerShape(50))
                            .neonGlow(color = SaqrNeonBlue, radius = 12f, alpha = 0.8f)
                    )
                    Text(
                        text = "KERNEL_SPACE_ACTIVE",
                        color = SaqrNeonBlue,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Tab Navigation header or control bar
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        // Core Dashboard / Home
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            contentPadding = PaddingValues(bottom = 16.dp)
                        ) {
                            item {
                                // Real-time Cyberpunk Telemetry (SystemDash Composable)
                                SystemDash(
                                    ramUsageMb = uiState.ramUsageMb,
                                    inferenceLatencyMs = uiState.inferenceLatencyMs,
                                    hasSecureSettings = uiState.hasSecureSettingsPermission
                                )
                            }

                            item {
                                // SaqrAiCore Box
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .neonGlow(color = if (uiState.isProcessing) SaqrNeonRed else SaqrNeonBlue, radius = 8f, alpha = 0.2f),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF101010)),
                                    border = BorderStroke(1.dp, Color(0xFF202020)),
                                    shape = RoundedCornerShape(20.dp)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        // Inner Header
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(
                                                    text = "SaqrAiCore Engine",
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp,
                                                    letterSpacing = 1.sp,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                                Text(
                                                    text = "Phi-3.5-mini-instruct • 4-bit Local Engine",
                                                    color = Color.Gray,
                                                    fontSize = 10.sp
                                                )
                                            }

                                            Box(
                                                modifier = Modifier
                                                    .background(
                                                        if (uiState.isProcessing) SaqrNeonRed.copy(alpha = 0.1f) else SaqrNeonBlue.copy(alpha = 0.1f),
                                                        RoundedCornerShape(4.dp)
                                                    )
                                                    .border(
                                                        1.dp,
                                                        if (uiState.isProcessing) SaqrNeonRed.copy(alpha = 0.2f) else SaqrNeonBlue.copy(alpha = 0.2f),
                                                        RoundedCornerShape(4.dp)
                                                    )
                                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                            ) {
                                                Text(
                                                    text = if (uiState.isProcessing) "INFERENCE ACTIVE" else "STANDBY",
                                                    color = if (uiState.isProcessing) SaqrNeonRed else SaqrNeonBlue,
                                                    fontSize = 9.sp,
                                                    fontFamily = FontFamily.Monospace,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))

                                        // Context analyzer log
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                                .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(6.dp)
                                                    .background(SaqrNeonBlue, shape = RoundedCornerShape(50))
                                            )
                                            Text(
                                                text = if (uiState.isProcessing) "Regulating CPU Core TDP..." else "Analyzing context: [Smart Power Optimizer Active]",
                                                color = Color.LightGray,
                                                fontSize = 11.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))

                                        // Model Outputs
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .heightIn(min = 100.dp)
                                                .background(Color(0xFF0A0A0A), RoundedCornerShape(12.dp))
                                                .border(1.dp, Color(0xFF1A1A1A), RoundedCornerShape(12.dp))
                                                .padding(12.dp)
                                        ) {
                                            if (uiState.aiResponse.isNotEmpty()) {
                                                Text(
                                                    text = uiState.aiResponse,
                                                    color = Color.White,
                                                    fontSize = 13.sp,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                            } else {
                                                Text(
                                                    text = "مرحباً... نظام صقر في وضع الاستعداد بانتظار أوامرك.",
                                                    color = Color.Gray,
                                                    fontSize = 13.sp
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))

                                        // Interactive parsed command helper
                                        val lastCommand = if (uiState.aiResponse.contains("[CMD:")) {
                                            val start = uiState.aiResponse.indexOf("[CMD:")
                                            val end = uiState.aiResponse.indexOf("]", start)
                                            if (end > start) uiState.aiResponse.substring(start, end + 1) else null
                                        } else null

                                        if (lastCommand != null) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(SaqrNeonBlue.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                                                    .border(1.dp, SaqrNeonBlue.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                                                    .padding(12.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column {
                                                    Text(
                                                        text = "EXECUTE SYSTEM DIRECTIVE",
                                                        color = SaqrNeonBlue,
                                                        fontSize = 8.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        letterSpacing = 1.sp
                                                    )
                                                    Text(
                                                        text = lastCommand,
                                                        color = Color.White,
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        fontFamily = FontFamily.Monospace
                                                    )
                                                }
                                                Text(
                                                    text = "COMPLETED",
                                                    color = SaqrNeonBlue,
                                                    fontSize = 10.sp,
                                                    fontFamily = FontFamily.Monospace,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            item {
                                // Next-Gen: Context-Aware Visual Awareness Card
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .neonGlow(color = SaqrNeonBlue, radius = 6f, alpha = 0.1f),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF101010)),
                                    border = BorderStroke(1.dp, Color(0xFF222222)),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(
                                                    text = "Context-Aware Visual Awareness",
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp
                                                )
                                                Text(
                                                    text = "Real-time screenshot OCR & content understanding",
                                                    color = Color.Gray,
                                                    fontSize = 10.sp
                                                )
                                            }
                                            Button(
                                                onClick = { viewModel.triggerScreenVisualAnalysis() },
                                                colors = ButtonDefaults.buttonColors(containerColor = SaqrNeonBlue.copy(alpha = 0.15f)),
                                                border = BorderStroke(1.dp, SaqrNeonBlue),
                                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                                modifier = Modifier.height(28.dp)
                                            ) {
                                                Text("SCAN SCREEN", color = SaqrNeonBlue, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(10.dp))

                                        val context = uiState.currentVisualContext
                                        if (context != null) {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(Color.Black, RoundedCornerShape(8.dp))
                                                    .border(1.dp, Color(0xFF333333), RoundedCornerShape(8.dp))
                                                    .padding(12.dp),
                                                verticalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Text(
                                                        text = "DETECTED: ${context.detectedObjectType}",
                                                        color = SaqrNeonBlue,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        fontFamily = FontFamily.Monospace
                                                    )
                                                    Text(
                                                        text = "CONFIDENCE: ${(context.confidence * 100).toInt()}%",
                                                        color = Color.Green,
                                                        fontSize = 9.sp,
                                                        fontFamily = FontFamily.Monospace
                                                    )
                                                }
                                                Text(
                                                    text = context.contentDescription,
                                                    color = Color.White,
                                                    fontSize = 11.sp
                                                )
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .background(SaqrNeonBlue.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                                        .border(1.dp, SaqrNeonBlue.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                                                        .clickable {
                                                            viewModel.submitPrompt("Execute suggested action: ${context.suggestedActionCommand}")
                                                        }
                                                        .padding(8.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = "SUGGESTED ACTION: ${context.suggestedActionTitle}",
                                                        color = Color.White,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        } else {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(Color(0xFF141414), RoundedCornerShape(8.dp))
                                                    .padding(12.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = "No screenshot capture loaded. Press SCAN SCREEN to capture a mock viewport.",
                                                    color = Color.Gray,
                                                    fontSize = 10.sp,
                                                    fontStyle = FontStyle.Italic
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    1 -> {
                        ChatScreen(
                            viewModel = chatViewModel,
                            onBack = { selectedTab = 0 }
                        )
                    }
                    2 -> {
                        // Automate / AI-Predictive Action & Unified Data Tunnel
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Next-Gen Low-Level Automation",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )

                            // APP PREFETCHING
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF101010)),
                                border = BorderStroke(1.dp, Color(0xFF222222)),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = "AI-Predictive App Pre-fetching",
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                            Text(
                                                text = "Kernel-level preloading based on habit modeling",
                                                color = Color.Gray,
                                                fontSize = 10.sp
                                            )
                                        }
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            IconButton(
                                                onClick = { viewModel.runHabitAnalysisAndPrefetch() },
                                                modifier = Modifier.size(28.dp).background(Color(0xFF1C1C1C), RoundedCornerShape(50))
                                            ) {
                                                Icon(imageVector = Icons.Default.Refresh, contentDescription = "Refresh", tint = SaqrNeonBlue, modifier = Modifier.size(14.dp))
                                            }
                                            Button(
                                                onClick = { viewModel.forcePrefetchAll() },
                                                colors = ButtonDefaults.buttonColors(containerColor = SaqrNeonBlue.copy(alpha = 0.15f)),
                                                border = BorderStroke(1.dp, SaqrNeonBlue),
                                                contentPadding = PaddingValues(horizontal = 8.dp),
                                                modifier = Modifier.height(28.dp)
                                            ) {
                                                Text("PRE-LOAD ALL", color = SaqrNeonBlue, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        uiState.prefetchApps.forEach { app ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(Color.Black, RoundedCornerShape(8.dp))
                                                    .border(1.dp, Color(0xFF222222), RoundedCornerShape(8.dp))
                                                    .padding(10.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column {
                                                    Text(text = app.appName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                                    Text(text = app.packageName, color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                                    Text(
                                                        text = String.format(Locale.US, "Habit Confidence: %.0f%%", app.predictionScore * 100),
                                                        color = SaqrNeonBlue,
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                                Column(horizontalAlignment = Alignment.End) {
                                                    if (app.isPreloaded) {
                                                        Box(
                                                            modifier = Modifier
                                                                .background(SaqrNeonBlue.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                                                .border(1.dp, SaqrNeonBlue.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                                                                .clickable { viewModel.releasePrefetchApp(app.packageName) }
                                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                                        ) {
                                                            Text(
                                                                text = "PRELOADED (${app.ramAllocatedMb}MB)",
                                                                color = SaqrNeonBlue,
                                                                fontSize = 8.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                fontFamily = FontFamily.Monospace
                                                            )
                                                        }
                                                        Spacer(modifier = Modifier.height(2.dp))
                                                        Text(text = "Saved ${app.launchLatencySavedMs}ms", color = Color.Green, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                                    } else {
                                                        Box(
                                                            modifier = Modifier
                                                                .background(Color(0xFF222222), RoundedCornerShape(4.dp))
                                                                .clickable { viewModel.forcePrefetchAll() }
                                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                                        ) {
                                                            Text(
                                                                text = "DORMANT",
                                                                color = Color.Gray,
                                                                fontSize = 8.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                fontFamily = FontFamily.Monospace
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // CROSS-APP NOTIFICATION TUNNEL
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF101010)),
                                border = BorderStroke(1.dp, Color(0xFF222222)),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Icon(imageVector = Icons.Default.Notifications, contentDescription = null, tint = SaqrNeonBlue)
                                            Column {
                                                Text(
                                                    text = "Cross-App notification Tunnel",
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp
                                                )
                                                Text(
                                                    text = "Bundles WhatsApp, Gmail & Messenger briefings",
                                                    color = Color.Gray,
                                                    fontSize = 10.sp
                                                )
                                            }
                                        }
                                        Button(
                                            onClick = { viewModel.generateNotificationBriefing() },
                                            colors = ButtonDefaults.buttonColors(containerColor = SaqrNeonBlue.copy(alpha = 0.15f)),
                                            border = BorderStroke(1.dp, SaqrNeonBlue),
                                            contentPadding = PaddingValues(horizontal = 8.dp),
                                            modifier = Modifier.height(28.dp)
                                        ) {
                                            Text("COMPILE BRIEF", color = SaqrNeonBlue, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        uiState.notifications.take(3).forEach { notif ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(Color.Black, RoundedCornerShape(6.dp))
                                                    .padding(8.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                                        Box(
                                                            modifier = Modifier
                                                                .background(
                                                                    if (notif.appName == "Gmail") SaqrNeonRed.copy(alpha = 0.2f) else SaqrNeonBlue.copy(alpha = 0.2f),
                                                                    RoundedCornerShape(4.dp)
                                                                )
                                                                .padding(horizontal = 4.dp, vertical = 2.dp)
                                                        ) {
                                                            Text(text = notif.appName, color = if (notif.appName == "Gmail") SaqrNeonRed else SaqrNeonBlue, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                                        }
                                                        Text(text = notif.senderName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                                    }
                                                    Text(text = notif.messageContent, color = Color.LightGray, fontSize = 10.sp, maxLines = 1)
                                                }
                                                Text(text = "Unread", color = SaqrNeonBlue, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                            }
                                        }
                                    }
                                }
                            }

                            // ZERO-LATENCY SENSOR EVENT BUS
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF101010)),
                                border = BorderStroke(1.dp, Color(0xFF222222)),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = "Zero-Latency Event Bus",
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                            Text(
                                                text = "Bypassing Android's normal execution cycles",
                                                color = Color.Gray,
                                                fontSize = 10.sp
                                            )
                                        }
                                        Button(
                                            onClick = { viewModel.simulateSensors() },
                                            colors = ButtonDefaults.buttonColors(containerColor = SaqrNeonBlue.copy(alpha = 0.15f)),
                                            border = BorderStroke(1.dp, SaqrNeonBlue),
                                            contentPadding = PaddingValues(horizontal = 8.dp),
                                            modifier = Modifier.height(28.dp)
                                        ) {
                                            Text("POLL SENSORS", color = SaqrNeonBlue, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    if (uiState.sensorEvents.isEmpty()) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(60.dp)
                                                .background(Color.Black, RoundedCornerShape(8.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("Awaiting Event Bus traffic...", color = Color.Gray, fontSize = 10.sp)
                                        }
                                    } else {
                                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            uiState.sensorEvents.take(3).forEach { event ->
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .background(Color.Black, RoundedCornerShape(6.dp))
                                                        .padding(6.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                        Text(text = "[${event.sensorType}]", color = SaqrNeonBlue, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                                        Text(text = String.format(Locale.US, "X=%.2f Y=%.2f Z=%.2f", event.x, event.y, event.z), color = Color.White, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                                    }
                                                    Text(
                                                        text = "Transit: ${event.deliveryLatencyNano}ns",
                                                        color = Color.Green,
                                                        fontSize = 9.sp,
                                                        fontFamily = FontFamily.Monospace,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    3 -> {
                        // Config / Thermal Governor & Accessibility Hooks
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            Text(
                                text = "Smart CPU governor & Hooks",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )

                            // CPU GOVERNOR CONTROL
                            val gov = uiState.governorMetrics
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF101010)),
                                border = BorderStroke(1.dp, Color(0xFF222222)),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = "Smart CPU Governor (Thermal Throttle)",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "Controls TDP and clock cycles to mitigate device heat during local inference",
                                        color = Color.Gray,
                                        fontSize = 10.sp
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(text = "GOVERNOR STATE", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                            Text(text = gov.cpuGovernorMode, color = SaqrNeonBlue, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                        }
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(text = "CORE TEMPERATURE", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                            Text(text = "${gov.coreTemperatureC}°C", color = if (gov.coreTemperatureC > 40) SaqrNeonRed else Color.Green, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(text = "CLOCK FREQUENCY", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                            Text(text = "${gov.cpuFrequencyGhz} GHz", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                        }
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(text = "POWER EFFICIENCY", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                            Text(text = "+${gov.powerEfficiencySavedPct}% SAVED", color = Color.Green, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = { viewModel.setGovernorMode("SaqrSchedUtil") },
                                            colors = ButtonDefaults.buttonColors(containerColor = if (gov.cpuGovernorMode == "SaqrSchedUtil") SaqrNeonBlue else Color(0xFF141414)),
                                            border = BorderStroke(1.dp, if (gov.cpuGovernorMode == "SaqrSchedUtil") SaqrNeonBlue else Color(0xFF333333)),
                                            modifier = Modifier.weight(1f),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("SCHEDUTIL", color = if (gov.cpuGovernorMode == "SaqrSchedUtil") Color.Black else Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Button(
                                            onClick = { viewModel.setGovernorMode("performance") },
                                            colors = ButtonDefaults.buttonColors(containerColor = if (gov.cpuGovernorMode == "performance") SaqrNeonRed else Color(0xFF141414)),
                                            border = BorderStroke(1.dp, if (gov.cpuGovernorMode == "performance") SaqrNeonRed else Color(0xFF333333)),
                                            modifier = Modifier.weight(1f),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("PERFORMANCE", color = if (gov.cpuGovernorMode == "performance") Color.Black else Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Button(
                                            onClick = { viewModel.setGovernorMode("restore") },
                                            colors = ButtonDefaults.buttonColors(containerColor = if (gov.cpuGovernorMode == "schedutil") SaqrNeonBlue else Color(0xFF141414)),
                                            border = BorderStroke(1.dp, if (gov.cpuGovernorMode == "schedutil") SaqrNeonBlue else Color(0xFF333333)),
                                            modifier = Modifier.weight(1f),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("DEFAULT", color = if (gov.cpuGovernorMode == "schedutil") Color.Black else Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            // SYSTEM LEVEL ACCESSIBILITY HOOKS
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF101010)),
                                border = BorderStroke(1.dp, Color(0xFF222222)),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = "System-Level Accessibility Hooks",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "Direct View Hierarchy manipulation to toggle system settings rapidly",
                                        color = Color.Gray,
                                        fontSize = 10.sp
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = { viewModel.runAccessibilityHook("TOGGLE_HOTSPOT") },
                                            colors = ButtonDefaults.buttonColors(containerColor = SaqrNeonBlue.copy(alpha = 0.15f)),
                                            border = BorderStroke(1.dp, SaqrNeonBlue),
                                            modifier = Modifier.weight(1f),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("TOGGLE HOTSPOT", color = SaqrNeonBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Button(
                                            onClick = { viewModel.runAccessibilityHook("SET_REFRESH_120HZ") },
                                            colors = ButtonDefaults.buttonColors(containerColor = SaqrNeonBlue.copy(alpha = 0.15f)),
                                            border = BorderStroke(1.dp, SaqrNeonBlue),
                                            modifier = Modifier.weight(1f),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("FORCE 120HZ RATE", color = SaqrNeonBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    if (uiState.lastAccessibilityResult.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color.Black, RoundedCornerShape(8.dp))
                                                .border(1.dp, Color(0xFF333333), RoundedCornerShape(8.dp))
                                                .padding(10.dp)
                                        ) {
                                            Text(
                                                text = "ACCESSIBILITY HOOK OUTPUT LOG:",
                                                color = SaqrNeonBlue,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = uiState.lastAccessibilityResult,
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }
                                }
                            }

                            // Secure Settings ADB Helper Card
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF101010)),
                                border = BorderStroke(1.dp, Color(0xFF202020)),
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = "SystemSettingsManager Core",
                                                color = Color.White,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = if (uiState.hasSecureSettingsPermission) "WRITE_SECURE_SETTINGS: Granted" else "WRITE_SECURE_SETTINGS: Missing",
                                                color = if (uiState.hasSecureSettingsPermission) SaqrNeonBlue else SaqrNeonRed,
                                                fontSize = 11.sp
                                            )
                                        }
                                        Box(
                                            modifier = Modifier
                                                .background(
                                                    if (uiState.hasSecureSettingsPermission) SaqrNeonBlue.copy(alpha = 0.1f) else SaqrNeonRed.copy(alpha = 0.1f),
                                                    RoundedCornerShape(4.dp)
                                                )
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = if (uiState.hasSecureSettingsPermission) "ACTIVE" else "ADB REQ",
                                                color = if (uiState.hasSecureSettingsPermission) SaqrNeonBlue else SaqrNeonRed,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }

                                    if (!uiState.hasSecureSettingsPermission) {
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            text = "To allow صقر SAQR to adjust Secure Settings offline, copy and execute this ADB command on your workstation:",
                                            color = Color.Gray,
                                            fontSize = 11.sp
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color.Black, RoundedCornerShape(8.dp))
                                                .border(1.dp, Color(0xFF333333), RoundedCornerShape(8.dp))
                                                .clickable {
                                                    clipboardManager.setText(AnnotatedString(uiState.adbCommand))
                                                }
                                                .padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = uiState.adbCommand,
                                                color = SaqrNeonBlue,
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Text(
                                                text = "COPY",
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Voice/Speech State Toast-Like Status Bar & Input Area (hidden inside ChatScreen tab)
            if (selectedTab != 1) {
                if (uiState.speechState !is SpeechState.Idle) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .background(
                                when (uiState.speechState) {
                                    is SpeechState.Listening -> SaqrNeonBlue.copy(alpha = 0.15f)
                                    is SpeechState.Processing -> Color.Yellow.copy(alpha = 0.15f)
                                    is SpeechState.Error -> SaqrNeonRed.copy(alpha = 0.15f)
                                    else -> Color(0xFF222222)
                                },
                                RoundedCornerShape(8.dp)
                            )
                            .border(
                                1.dp,
                                when (uiState.speechState) {
                                    is SpeechState.Listening -> SaqrNeonBlue
                                    is SpeechState.Processing -> Color.Yellow
                                    is SpeechState.Error -> SaqrNeonRed
                                    else -> Color.Gray
                                },
                                RoundedCornerShape(8.dp)
                            )
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(
                                    when (uiState.speechState) {
                                        is SpeechState.Listening -> SaqrNeonBlue
                                        is SpeechState.Processing -> Color.Yellow
                                        is SpeechState.Error -> SaqrNeonRed
                                        else -> Color.Gray
                                    },
                                    shape = RoundedCornerShape(50)
                                )
                        )
                        Text(
                            text = when (val state = uiState.speechState) {
                                is SpeechState.Listening -> "Listening... Speak now."
                                is SpeechState.Processing -> "Processing offline voice..."
                                is SpeechState.Success -> "Recognized: \"${state.text}\""
                                is SpeechState.Error -> "Speech Error: ${state.message}"
                                is SpeechState.NotAvailable -> "Speech engine offline or unavailable."
                                else -> "Speech status ready."
                            },
                            color = Color.White,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Input Area
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            if (uiState.speechState is SpeechState.Listening) {
                                viewModel.stopListening()
                            } else {
                                viewModel.startListening()
                            }
                        },
                        modifier = Modifier
                            .background(
                                if (uiState.speechState is SpeechState.Listening) SaqrNeonRed.copy(alpha = 0.2f) else SaqrNeonBlue.copy(alpha = 0.1f),
                                RoundedCornerShape(50)
                            )
                            .neonGlow(
                                color = if (uiState.speechState is SpeechState.Listening) SaqrNeonRed else SaqrNeonBlue,
                                radius = 12f,
                                alpha = 0.6f
                            ),
                    ) {
                        MicIcon(
                            tint = if (uiState.speechState is SpeechState.Listening) SaqrNeonRed else SaqrNeonBlue
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("prompt_input"),
                        placeholder = { Text("أدخل أمر النظام...", color = Color.Gray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SaqrNeonBlue,
                            unfocusedBorderColor = SaqrNeonBlue.copy(alpha = 0.4f),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(24.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                viewModel.submitPrompt(inputText)
                                inputText = ""
                            }
                        },
                        modifier = Modifier
                            .background(SaqrNeonBlue.copy(alpha = 0.1f), RoundedCornerShape(50))
                            .neonGlow(color = SaqrNeonBlue, radius = 12f, alpha = 0.5f)
                            .testTag("send_button"),
                        enabled = !uiState.isProcessing
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send",
                            tint = SaqrNeonBlue
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Bottom Navigation matching Elegant Dark style precisely
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.9f))
                    .border(BorderStroke(1.dp, Color(0xFF111111)))
                    .padding(vertical = 12.dp, horizontal = 24.dp)
                    .navigationBarsPadding(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val tabs = listOf(
                    Triple("Core", Icons.Default.Home, 0),
                    Triple("Intelligence", Icons.Default.Star, 1),
                    Triple("Automate", Icons.Default.PlayArrow, 2),
                    Triple("Config", Icons.Default.Settings, 3)
                )

                tabs.forEach { (label, icon, index) ->
                    val isSelected = selectedTab == index
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable { selectedTab = index }
                            .padding(horizontal = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (isSelected) {
                            Box(
                                modifier = Modifier
                                    .width(24.dp)
                                    .height(2.dp)
                                    .background(SaqrNeonBlue, RoundedCornerShape(1.dp))
                                    .neonGlow(color = SaqrNeonBlue, radius = 4f, alpha = 0.8f)
                            )
                        } else {
                            Spacer(modifier = Modifier.height(2.dp))
                        }

                        Icon(
                            imageVector = icon,
                            contentDescription = label,
                            tint = if (isSelected) SaqrNeonBlue else Color.White.copy(alpha = 0.4f),
                            modifier = Modifier.size(20.dp)
                        )

                        Text(
                            text = label,
                            color = if (isSelected) SaqrNeonBlue else Color.White.copy(alpha = 0.4f),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        }

        // Floating AI Hub / Overlay Controller (Top right bubble)
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 90.dp, end = 16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .background(
                        if (uiState.activeOverlay) SaqrNeonRed.copy(alpha = 0.2f) else SaqrNeonBlue.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(50)
                    )
                    .border(
                        BorderStroke(
                            2.dp,
                            if (uiState.activeOverlay) SaqrNeonRed else SaqrNeonBlue
                        ),
                        shape = RoundedCornerShape(50)
                    )
                    .neonGlow(
                        color = if (uiState.activeOverlay) SaqrNeonRed else SaqrNeonBlue,
                        radius = 12f,
                        alpha = 0.8f
                    )
                    .clickable { viewModel.toggleOverlay() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Floating Hub Toggle",
                    tint = if (uiState.activeOverlay) SaqrNeonRed else SaqrNeonBlue,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        // UI Overlay: Floating AI Hub Panel (Animated)
        AnimatedVisibility(
            visible = uiState.activeOverlay,
            enter = fadeIn() + slideInVertically(initialOffsetY = { -it }),
            exit = fadeOut() + slideOutVertically(targetOffsetY = { -it }),
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .align(Alignment.Center)
        ) {
            Card(
                modifier = Modifier
                    .border(BorderStroke(2.dp, SaqrNeonRed), RoundedCornerShape(24.dp))
                    .neonGlow(color = SaqrNeonRed, radius = 20f, alpha = 0.4f),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F0606)),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).background(SaqrNeonRed, RoundedCornerShape(50)).neonGlow(color = SaqrNeonRed))
                            Text(
                                text = "SAQR OVERLAY CONTROL",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 1.sp
                            )
                        }
                        IconButton(
                            onClick = { viewModel.toggleOverlay() },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Text("×", color = Color.Gray, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Text(
                        text = "Real-Time OS Controller active above screen buffers. Fast bypass channels ready for low-latency directives.",
                        color = Color.LightGray,
                        fontSize = 11.sp
                    )

                    // Quick buttons
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(SaqrNeonRed.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                                    .border(1.dp, SaqrNeonRed.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                    .clickable {
                                        viewModel.submitPrompt("kill background memory pressure")
                                        viewModel.toggleOverlay()
                                    }
                                    .padding(12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("HIBERNATE MEMORY", color = SaqrNeonRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(SaqrNeonBlue.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                                    .border(1.dp, SaqrNeonBlue.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                    .clickable {
                                        viewModel.setGovernorMode("SaqrSchedUtil")
                                        viewModel.toggleOverlay()
                                    }
                                    .padding(12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("GOVERNOR MODE", color = SaqrNeonBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black, RoundedCornerShape(12.dp))
                                .border(1.dp, Color(0xFF222222), RoundedCornerShape(12.dp))
                                .clickable {
                                    viewModel.generateNotificationBriefing()
                                    viewModel.toggleOverlay()
                                }
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(6.dp).background(Color.Green, RoundedCornerShape(50)))
                                Text("COMPILE INTEL BRIEF (CROSS-APP TUNNEL)", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // System health summary in overlay
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF140808), RoundedCornerShape(12.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("CPU THERMAL GOVERNOR", color = Color.Gray, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text("SaqrSchedUtil Active", color = Color.Green, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("ACTIVE DIRECTIVES", color = Color.Gray, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text("98.4% EFFICIENCY", color = SaqrNeonBlue, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

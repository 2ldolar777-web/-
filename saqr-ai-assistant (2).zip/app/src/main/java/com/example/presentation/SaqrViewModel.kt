package com.example.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.automation.SystemSettingsManager
import com.example.core.*
import com.example.speech.OfflineSpeechRecognizer
import com.example.speech.SpeechState
import com.example.data.FeedbackLog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SaqrViewModel(
    private val localAiManager: LocalAiManager,
    private val commandProcessor: CommandProcessor,
    private val tokenBudgetManager: TokenBudgetManager,
    private val settingsManager: SystemSettingsManager,
    private val privacyVaultRepository: PrivacyVaultRepository,
    private val prefetchEngine: SaqrPrefetchEngine,
    private val visualContextAnalyzer: SaqrVisualContextAnalyzer,
    private val thermalGovernor: SaqrThermalGovernor,
    private val notificationTunnel: SaqrNotificationTunnel,
    private val sensorEventBus: SaqrSensorEventBus,
    private val accessibilityHookService: SaqrAccessibilityHookService,
    private val speechRecognizer: OfflineSpeechRecognizer
) : ViewModel() {

    private val _uiState = MutableStateFlow(SaqrUiState())
    val uiState: StateFlow<SaqrUiState> = _uiState.asStateFlow()

    init {
        checkPermissions()
        _uiState.value = _uiState.value.copy(
            adbCommand = settingsManager.getAdbCommandInstruction()
        )
        observeSpeechRecognizer()
        observePrefetchEngine()
        observeVisualContext()
        observeThermalGovernor()
        observeNotificationTunnel()
        observeSensorEventBus()
        observePrivacyVault()
    }

    private fun checkPermissions() {
        val hasSecure = settingsManager.hasSecureSettingsPermission()
        _uiState.value = _uiState.value.copy(hasSecureSettingsPermission = hasSecure)
    }

    private fun observeSpeechRecognizer() {
        viewModelScope.launch {
            speechRecognizer.state.collect { speechState ->
                _uiState.value = _uiState.value.copy(speechState = speechState)
                if (speechState is SpeechState.Success) {
                    submitPrompt(speechState.text)
                }
            }
        }
    }

    private fun observePrefetchEngine() {
        viewModelScope.launch {
            prefetchEngine.prefetchState.collect { apps ->
                _uiState.value = _uiState.value.copy(
                    prefetchApps = apps,
                    ramUsageMb = 850 + prefetchEngine.getTotalPreloadedRamMb()
                )
            }
        }
    }

    private fun observeVisualContext() {
        viewModelScope.launch {
            visualContextAnalyzer.currentContext.collect { context ->
                _uiState.value = _uiState.value.copy(currentVisualContext = context)
            }
        }
    }

    private fun observeThermalGovernor() {
        viewModelScope.launch {
            thermalGovernor.metrics.collect { metrics ->
                _uiState.value = _uiState.value.copy(governorMetrics = metrics)
            }
        }
    }

    private fun observeNotificationTunnel() {
        viewModelScope.launch {
            notificationTunnel.notifications.collect { notifications ->
                _uiState.value = _uiState.value.copy(notifications = notifications)
            }
        }
    }

    private fun observeSensorEventBus() {
        viewModelScope.launch {
            val recentEvents = mutableListOf<SensorEvent>()
            sensorEventBus.eventBusStream.collect { event ->
                recentEvents.add(0, event)
                if (recentEvents.size > 10) recentEvents.removeAt(recentEvents.size - 1)
                _uiState.value = _uiState.value.copy(sensorEvents = ArrayList(recentEvents))
            }
        }
    }

    private fun observePrivacyVault() {
        viewModelScope.launch {
            privacyVaultRepository.getFeedbacksFlow().collect { list ->
                _uiState.value = _uiState.value.copy(recentFeedbacks = list)
            }
        }
    }

    fun startListening() {
        speechRecognizer.startListening()
    }

    fun stopListening() {
        speechRecognizer.stopListening()
    }

    // PersonaInterceptor - wraps prompts on-the-fly with Egyptian colloquial system prompt
    object PersonaInterceptor {
        private const val SYSTEM_PROMPT = """
أنت "صقر" (Saqr AI OS Core)، مساعد ذكي مصري أصيل، صايع وجدع جداً.
بتعامل المستخدم دايماً على إنه "أبو صقر".
طريقتك في الكلام بالعامية المصرية خفيفة الدم، وبتستخدم إيموجي 😂 كتير.
المستخدم ممكن يطلب منك تحكم في الموبايل أو أتمتة (زي تشغيل الواي فاي، البلوتوث، أو توفير الرام).
لما يطلب حاجة زي كدة، لازم تحط الأمر المناسب في ردك بالصيغة دي بالظبط:
- للتحكم في الواي فاي: [CMD:WIFI_ON] أو [CMD:WIFI_OFF]
- للتحكم في الرام (تنظيف الرام/SmartHibernate): [CMD:OPTIMIZE_RAM]
- لإرسال رسائل أو تشغيل مهام تذكر (Tasker): [CMD:TASKER_INTENT:اسم_المهمة]

مثال للرد: "يا مرحب يا أبو صقر! 😂 عيوني ليك، هقفل الواي فاي حالاً عشان نوفر البطارية. [CMD:WIFI_OFF]"
رد دايماً بلهجة مصرية عامية جدعة وسريعة ومرحة جداً، والتزم بإنك مساعد محلي شغال جوة نظام Saqr AI OS Core على Redmi 14C.
"""

        fun intercept(userPrompt: String): String {
            return "<|system|>\n$SYSTEM_PROMPT\n<|user|>\n$userPrompt\n<|assistant|>\n"
        }
    }

    fun submitPrompt(prompt: String) {
        if (!tokenBudgetManager.checkBudget()) {
            _uiState.value = _uiState.value.copy(
                aiResponse = "RAM limit exceeded. SmartHibernate required.",
                isProcessing = false
            )
            return
        }

        _uiState.value = _uiState.value.copy(isProcessing = true, aiResponse = "", currentPrompt = prompt)
        
        // Optimally adjust governor for active inference load
        thermalGovernor.optimizeForInference()

        viewModelScope.launch {
            var fullOutput = ""
            val startTime = System.currentTimeMillis()
            val interceptedPrompt = PersonaInterceptor.intercept(prompt)
            localAiManager.generateStreamingResponse(interceptedPrompt).collect { chunk ->
                fullOutput += chunk
                _uiState.value = _uiState.value.copy(
                    aiResponse = fullOutput,
                    inferenceLatencyMs = System.currentTimeMillis() - startTime
                )
            }
            
            val action = commandProcessor.parseAndExecute(fullOutput)
            _uiState.value = _uiState.value.copy(isProcessing = false)
            
            // Restore power saving or default schedule governor
            thermalGovernor.restoreNormalMode()
            
            // Save feedback log securely encrypted using AES-128
            privacyVaultRepository.saveFeedback(prompt, fullOutput, true)
        }
    }

    // Interactive Pre-fetch methods
    fun runHabitAnalysisAndPrefetch() {
        prefetchEngine.runHabitAnalysisAndPrefetch()
    }

    fun forcePrefetchAll() {
        prefetchEngine.forcePreloadAll()
    }

    fun releasePrefetchApp(packageName: String) {
        prefetchEngine.releasePreloadedApp(packageName)
    }

    // Screen Visual context analysis
    fun triggerScreenVisualAnalysis() {
        visualContextAnalyzer.triggerScreenCaptureAndAnalyze()
    }

    fun clearScreenVisualContext() {
        visualContextAnalyzer.clear()
    }

    // CPU Governor Toggles
    fun setGovernorMode(mode: String) {
        when (mode) {
            "SaqrSchedUtil" -> thermalGovernor.optimizeForInference()
            "performance" -> thermalGovernor.triggerTurboMode()
            else -> thermalGovernor.restoreNormalMode()
        }
    }

    // Notification unified briefings
    fun generateNotificationBriefing() {
        val briefing = notificationTunnel.generateUnifiedBriefing()
        _uiState.value = _uiState.value.copy(aiResponse = briefing)
    }

    // Zero-latency sensory bus simulation
    fun simulateSensors() {
        viewModelScope.launch {
            sensorEventBus.generateMockSensorTraffic()
        }
    }

    // System accessibility hooks
    fun runAccessibilityHook(action: String) {
        val res = accessibilityHookService.executeQuickAction(action)
        _uiState.value = _uiState.value.copy(lastAccessibilityResult = res)
    }

    fun toggleOverlay() {
        _uiState.value = _uiState.value.copy(activeOverlay = !_uiState.value.activeOverlay)
    }

    fun setFeedbackSatisfaction(logId: Int, satisfied: Boolean) {
        // Simple log satisfaction helper (optional refinement)
    }

    override fun onCleared() {
        super.onCleared()
        speechRecognizer.destroy()
    }
}

data class SaqrUiState(
    val isProcessing: Boolean = false,
    val aiResponse: String = "",
    val currentPrompt: String = "",
    val inferenceLatencyMs: Long = 0,
    val ramUsageMb: Int = 850,
    val hasSecureSettingsPermission: Boolean = false,
    val adbCommand: String = "",
    val speechState: SpeechState = SpeechState.Idle,
    
    // Next-Gen additions
    val prefetchApps: List<PrefetchApp> = emptyList(),
    val currentVisualContext: VisualContext? = null,
    val governorMetrics: GovernorMetrics = GovernorMetrics("schedutil", 2.4, 38.0, false, 15),
    val notifications: List<AppNotification> = emptyList(),
    val sensorEvents: List<SensorEvent> = emptyList(),
    val recentFeedbacks: List<FeedbackLog> = emptyList(),
    val lastAccessibilityResult: String = "",
    val activeOverlay: Boolean = false
)

class SaqrViewModelFactory(
    private val localAiManager: LocalAiManager,
    private val commandProcessor: CommandProcessor,
    private val tokenBudgetManager: TokenBudgetManager,
    private val settingsManager: SystemSettingsManager,
    private val privacyVaultRepository: PrivacyVaultRepository,
    private val prefetchEngine: SaqrPrefetchEngine,
    private val visualContextAnalyzer: SaqrVisualContextAnalyzer,
    private val thermalGovernor: SaqrThermalGovernor,
    private val notificationTunnel: SaqrNotificationTunnel,
    private val sensorEventBus: SaqrSensorEventBus,
    private val accessibilityHookService: SaqrAccessibilityHookService,
    private val speechRecognizer: OfflineSpeechRecognizer
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SaqrViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SaqrViewModel(
                localAiManager,
                commandProcessor,
                tokenBudgetManager,
                settingsManager,
                privacyVaultRepository,
                prefetchEngine,
                visualContextAnalyzer,
                thermalGovernor,
                notificationTunnel,
                sensorEventBus,
                accessibilityHookService,
                speechRecognizer
            ) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

package com.example.presentation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.neonGlow
import com.example.ui.theme.SaqrNeonBlue
import com.example.ui.theme.SaqrNeonRed
import kotlinx.coroutines.launch
import androidx.compose.ui.graphics.asImageBitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.Add
import android.util.Log

// Neon Gradients for Cyberpunk Aesthetics
val CyberUserGradient = listOf(SaqrNeonBlue, Color(0xFF00B0FF))
val CyberAssistantGradient = listOf(Color(0xFFD500F9), SaqrNeonRed)
val CyberChipGradient = listOf(Color(0xFF111111), Color(0xFF050505))

/**
 * Cyberpunk gradient border modifier for neon message bubbles.
 */
fun Modifier.cyberBorder(
    colors: List<Color>,
    shape: RoundedCornerShape = RoundedCornerShape(16.dp),
    borderWidth: Dp = 1.5.dp
) = this.border(
    width = borderWidth,
    brush = Brush.linearGradient(colors = colors, tileMode = TileMode.Clamp),
    shape = shape
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    onBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var inputText by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val context = androidx.compose.ui.platform.LocalContext.current
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: android.net.Uri? ->
        uri?.let {
            try {
                val inputStream = context.contentResolver.openInputStream(it)
                val bytes = inputStream?.readBytes()
                if (bytes != null) {
                    viewModel.attachGalleryImage(bytes, "معرض_الصور.jpg")
                }
            } catch (e: Exception) {
                Log.e("ChatScreen", "Failed to load gallery image", e)
            }
        }
    }

    // Auto-scroll to bottom when messages list size changes
    LaunchedEffect(uiState.messages.size) {
        if (uiState.messages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Flashing Live Server Dot
                        val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                        val alpha by infiniteTransition.animateFloat(
                            initialValue = 0.2f,
                            targetValue = 1.0f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(1000, easing = LinearEasing),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "pulseAlpha"
                        )
                        
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(SaqrNeonBlue.copy(alpha = alpha))
                                .neonGlow(color = SaqrNeonBlue, radius = 6f, alpha = alpha)
                        )

                        Column {
                            Text(
                                text = "صقر AI OS • الشات الذكي",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "LOCAL_CORE_CONNECTED",
                                color = SaqrNeonBlue,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("chat_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF050505),
                    titleContentColor = Color.White
                ),
                modifier = Modifier.border(0.dp, Color.Transparent)
            )
        },
        containerColor = Color(0xFF0A0A0A) // Deep Cyberpunk dark canvas #0A0A0A
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .imePadding() // Adjust for software keyboard height elegantly
        ) {
            
            // Mode Selector Bar
            ModeSelectorBar(
                isGeminiMode = uiState.isGeminiMode,
                onModeSelected = { viewModel.toggleAiMode() }
            )
            
            // Error overlay
            AnimatedVisibility(visible = uiState.error != null) {
                uiState.error?.let { err ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SaqrNeonRed.copy(alpha = 0.15f))
                            .border(BorderStroke(1.dp, SaqrNeonRed))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = err,
                            color = SaqrNeonRed,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Chat Messages List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 16.dp)
            ) {
                items(uiState.messages) { message ->
                    ChatBubbleItem(message = message)
                }

                // Cyber Typing Active Indicator
                if (uiState.isProcessing && uiState.messages.lastOrNull()?.isUser == true) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(start = 12.dp, top = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(SaqrNeonBlue)
                                    .neonGlow(color = SaqrNeonBlue, radius = 4f)
                            )
                            Text(
                                text = "صقر يقوم بتحليل وقراءة المدخلات...",
                                color = Color.Gray,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                            )
                        }
                    }
                }
            }

            // Diagnostics & Screenshot Simulation Hub (Only visible in Gemini Mode!)
            if (uiState.isGeminiMode) {
                DiagnosticsSimulationHub(
                    onAttachMockImage = { type ->
                        viewModel.attachMockImage(type)
                    }
                )
            }

            // Quick Actions Hub row
            QuickActionHub(
                onChipClicked = { textToSend ->
                    // Fills field and triggers execution in background instantly
                    inputText = ""
                    viewModel.processInput(textToSend)
                }
            )

            // Attached Image Preview Bar
            if (uiState.attachedImageName != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1A0A0D))
                        .border(BorderStroke(1.dp, SaqrNeonRed.copy(alpha = 0.3f)))
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(SaqrNeonRed)
                        )
                        Text(
                            text = "مرفق: ${uiState.attachedImageName}",
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = "[إلغاء ❌]",
                        color = SaqrNeonRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.clickable { viewModel.clearAttachedImage() }
                    )
                }
            }

            // Input Bar Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF070707))
                    .border(BorderStroke(1.dp, Color(0xFF151515)))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Attach Gallery Image Button (Only visible in Gemini Mode!)
                if (uiState.isGeminiMode) {
                    IconButton(
                        onClick = { launcher.launch("image/*") },
                        modifier = Modifier
                            .size(46.dp)
                            .background(Color(0xFF111111), RoundedCornerShape(12.dp))
                            .border(BorderStroke(1.dp, Color(0xFF222222)), RoundedCornerShape(12.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Attach photo",
                            tint = Color.LightGray,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }

                // Multi-line intelligent input text field
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_prompt_input")
                        .heightIn(max = 120.dp),
                    placeholder = { 
                        Text(
                            text = "اسألني سؤال أو قولي 'قفل الواي فاي'...", 
                            color = Color.DarkGray,
                            fontSize = 13.sp
                        ) 
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF0F0F0F),
                        unfocusedContainerColor = Color(0xFF0A0A0A),
                        focusedBorderColor = SaqrNeonBlue,
                        unfocusedBorderColor = Color(0xFF222222),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(16.dp),
                    maxLines = 4,
                    keyboardOptions = KeyboardOptions(
                        imeAction = ImeAction.Default
                    ),
                    textStyle = LocalTextStyle.current.copy(
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Monospace
                    )
                )

                Spacer(modifier = Modifier.width(10.dp))

                // Neon Arrow Send Button
                IconButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            viewModel.processInput(inputText)
                            inputText = ""
                        }
                    },
                    modifier = Modifier
                        .size(46.dp)
                        .background(SaqrNeonBlue.copy(alpha = 0.12f), CircleShape)
                        .cyberBorder(colors = CyberUserGradient, shape = CircleShape, borderWidth = 1.5.dp)
                        .neonGlow(color = SaqrNeonBlue, radius = 10f, alpha = 0.5f)
                        .testTag("chat_send_button"),
                    enabled = !uiState.isProcessing && inputText.isNotBlank()
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = if (inputText.isNotBlank()) SaqrNeonBlue else Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

/**
 * Custom Styled Chat Bubble Item with glowing cyberpunk gradients and execution tracking badges.
 */
@Composable
fun ChatBubbleItem(message: ChatMessage) {
    val isUser = message.isUser
    val alignment = if (isUser) Alignment.End else Alignment.Start
    val gradientColors = if (isUser) CyberUserGradient else CyberAssistantGradient
    val bubbleBgColor = if (isUser) Color(0xFF0D0D0D) else Color(0xFF0F0814)

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = alignment
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(0.85f),
            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    ))
                    .background(bubbleBgColor)
                    .cyberBorder(colors = gradientColors, shape = RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    ), borderWidth = 1.2.dp)
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    message.attachedImageBytes?.let { bytes ->
                        val bitmap = remember(bytes) {
                            android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        }
                        if (bitmap != null) {
                            androidx.compose.foundation.Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "Attached screenshot",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 160.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .padding(bottom = 8.dp),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop
                            )
                        }
                    }

                    if (message.text.isNotBlank()) {
                        Text(
                            text = message.text,
                            color = Color.White,
                            fontSize = 13.5.sp,
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 20.sp,
                            textAlign = if (isUser) TextAlign.End else TextAlign.Start
                        )
                    }

                    // Display a highly polished neon system execution success badge inside the bubble
                    if (message.executedCommand != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .background(SaqrNeonBlue.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                                .border(BorderStroke(0.5.dp, SaqrNeonBlue.copy(alpha = 0.3f)), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(5.dp)
                                    .clip(CircleShape)
                                    .background(SaqrNeonBlue)
                                    .neonGlow(color = SaqrNeonBlue, radius = 4f)
                            )
                            Text(
                                text = "SECURE_DIRECTIVE: ${message.executedCommand} [SUCCESS]",
                                color = SaqrNeonBlue,
                                fontSize = 8.5.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Scrollable Horizontal Row containing Floating Neon Chips with pre-configured quick automation triggers.
 */
@Composable
fun QuickActionHub(
    onChipClicked: (String) -> Unit
) {
    val actions = listOf(
        Pair("فتح الواي فاي 📶", "شغل الواي فاي [CMD:WIFI_ON]"),
        Pair("إغلاق الواي فاي 📴", "قفل الواي فاي [CMD:WIFI_OFF]"),
        Pair("تنظيف الرام 🧹", "تنظيف الرام [CMD:OPTIMIZE_RAM]"),
        Pair("توفير الطاقة 🔋", "وضع توفير الطاقة [CMD:POWER_SAVE_ON]"),
        Pair("إغلاق البلوتوث 🔇", "إغلاق البلوتوث [CMD:BLUETOOTH_OFF]")
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp)
    ) {
        Text(
            text = "QUICK AUTOMATION HUB",
            color = Color.Gray,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp).padding(bottom = 6.dp),
            letterSpacing = 1.sp
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(38.dp)
            ) {
                // Horizontal scrollable flow
                androidx.compose.foundation.lazy.LazyRow(
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(actions) { action ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Brush.verticalGradient(CyberChipGradient))
                                .border(
                                    BorderStroke(1.dp, SaqrNeonBlue.copy(alpha = 0.25f)),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { onChipClicked(action.second) }
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = action.first,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Premium Mode Selector Bar to toggle between Local AI (Phi-3.5) and Cloud AI (Gemini 3.5).
 */
@Composable
fun ModeSelectorBar(
    isGeminiMode: Boolean,
    onModeSelected: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF070707))
            .border(BorderStroke(1.dp, Color(0xFF151515)))
            .padding(vertical = 8.dp, horizontal = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier
                .background(Color(0xFF111111), RoundedCornerShape(12.dp))
                .border(BorderStroke(1.dp, Color(0xFF222222)), RoundedCornerShape(12.dp))
                .padding(2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (!isGeminiMode) SaqrNeonBlue.copy(alpha = 0.15f) else Color.Transparent)
                    .clickable { if (isGeminiMode) onModeSelected() }
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "صقر المحلي (Phi-3.5 Offline)",
                    color = if (!isGeminiMode) SaqrNeonBlue else Color.Gray,
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isGeminiMode) SaqrNeonRed.copy(alpha = 0.15f) else Color.Transparent)
                    .clickable { if (!isGeminiMode) onModeSelected() }
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "صقر الفائق (Gemini 3.5 Online)",
                    color = if (isGeminiMode) SaqrNeonRed else Color.LightGray,
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

/**
 * Diagnostics & Screenshot Simulation Hub for quick testing of multimodal issue diagnosis.
 */
@Composable
fun DiagnosticsSimulationHub(
    onAttachMockImage: (String) -> Unit
) {
    val items = listOf(
        Triple("WIFI_ERROR", "📶 خطأ واي فاي", SaqrNeonBlue),
        Triple("RAM_FULL", "🧹 رامات ممتلئة", Color.Yellow),
        Triple("OVERHEATING", "🔥 حرارة مرتفعة", SaqrNeonRed)
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Text(
            text = "DIAGNOSTICS SCREENSHOT SIMULATION",
            color = Color.Gray,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 6.dp),
            letterSpacing = 1.sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items.forEach { (type, label, color) ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF111111))
                        .border(
                            BorderStroke(1.dp, color.copy(alpha = 0.35f)),
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { onAttachMockImage(type) }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

package com.example.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class VisualContext(
    val screenshotId: String,
    val detectedObjectType: String, // e.g., "Email Receipt", "Chat Conversation", "Flight Ticket"
    val contentDescription: String,
    val suggestedActionTitle: String,
    val suggestedActionCommand: String,
    val confidence: Float
)

class SaqrVisualContextAnalyzer {

    private val _currentContext = MutableStateFlow<VisualContext?>(null)
    val currentContext: StateFlow<VisualContext?> = _currentContext.asStateFlow()

    private val sampleScreenContexts = listOf(
        VisualContext(
            screenshotId = "scr_001",
            detectedObjectType = "Booking Confirmation",
            contentDescription = "Meeting with Design Team on Friday at 4:00 PM via Zoom",
            suggestedActionTitle = "Schedule Design Team Zoom in Calendar",
            suggestedActionCommand = "CALENDAR_ADD_ZOOM_FRIDAY_4PM",
            confidence = 0.96f
        ),
        VisualContext(
            screenshotId = "scr_002",
            detectedObjectType = "Chat Conversation (Delivery)",
            contentDescription = "Driver says: I'm at 142 Cyber Street, please come down",
            suggestedActionTitle = "Open Navigation for 142 Cyber Street",
            suggestedActionCommand = "MAPS_NAVIGATE_142_CYBER",
            confidence = 0.91f
        ),
        VisualContext(
            screenshotId = "scr_003",
            detectedObjectType = "Product Receipt",
            contentDescription = "Order #89326 from TechShop - Total: $1,240.00",
            suggestedActionTitle = "Track Shipment in Finance Manager",
            suggestedActionCommand = "FINANCE_TRACK_ORDER_89326",
            confidence = 0.88f
        )
    )

    private var currentIndex = 0

    fun triggerScreenCaptureAndAnalyze() {
        // Simulates taking screen buffer hierarchy & passing to local multimodal model
        val selectedContext = sampleScreenContexts[currentIndex]
        _currentContext.value = selectedContext
        
        // Cycle contexts for interactive simulation
        currentIndex = (currentIndex + 1) % sampleScreenContexts.size
    }

    fun clear() {
        _currentContext.value = null
    }
}

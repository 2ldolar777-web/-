package com.example.core

import android.util.Base64
import com.example.data.FeedbackDao
import com.example.data.FeedbackLog
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

class PrivacyVaultRepository(private val feedbackDao: FeedbackDao) {
    // 128-bit key for AES (Privacy-First Local Vault)
    private val keyBytes = "SaqrAIOsCoreVault".toByteArray().copyOf(16)
    private val secretKey = SecretKeySpec(keyBytes, "AES")

    fun encrypt(text: String): String {
        if (text.isEmpty()) return ""
        return try {
            val cipher = Cipher.getInstance("AES/ECB/PKCS5Padding")
            cipher.init(Cipher.ENCRYPT_MODE, secretKey)
            val encrypted = cipher.doFinal(text.toByteArray(Charsets.UTF_8))
            Base64.encodeToString(encrypted, Base64.NO_WRAP)
        } catch (e: Exception) {
            text // Fallback
        }
    }

    fun decrypt(encryptedText: String): String {
        if (encryptedText.isEmpty()) return ""
        return try {
            val cipher = Cipher.getInstance("AES/ECB/PKCS5Padding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey)
            val decoded = Base64.decode(encryptedText, Base64.NO_WRAP)
            String(cipher.doFinal(decoded), Charsets.UTF_8)
        } catch (e: Exception) {
            encryptedText // Fallback
        }
    }

    suspend fun saveFeedback(prompt: String, output: String, isSatisfied: Boolean = true) {
        val encryptedPrompt = encrypt(prompt)
        val encryptedOutput = encrypt(output)
        val log = FeedbackLog(
            prompt = encryptedPrompt,
            modelOutput = encryptedOutput,
            isSatisfied = isSatisfied
        )
        feedbackDao.insertFeedback(log)
    }

    fun getFeedbacksFlow(): Flow<List<FeedbackLog>> {
        return feedbackDao.getRecentFeedbacks().map { logs ->
            logs.map { log ->
                log.copy(
                    prompt = decrypt(log.prompt),
                    modelOutput = decrypt(log.modelOutput)
                )
            }
        }
    }
}

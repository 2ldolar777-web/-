package com.example.core

import com.example.automation.SaqrBridge

sealed class SaqrAction {
    data class SystemCommand(val command: String) : SaqrAction()
    data class TaskerIntent(val intentAction: String) : SaqrAction()
    data class TextResponse(val text: String) : SaqrAction()
}

class CommandProcessor(
    private val saqrBridge: SaqrBridge
) {
    fun parseAndExecute(aiOutput: String): SaqrAction {
        return if (aiOutput.contains("[CMD:")) {
            val cmdStart = aiOutput.indexOf("[CMD:") + 5
            val cmdEnd = aiOutput.indexOf("]", cmdStart)
            if (cmdEnd > cmdStart) {
                val fullCmd = aiOutput.substring(cmdStart, cmdEnd)
                if (fullCmd.startsWith("TASKER_INTENT:")) {
                    val intent = fullCmd.removePrefix("TASKER_INTENT:")
                    saqrBridge.triggerTaskerIntent(intent)
                    SaqrAction.TaskerIntent(intent)
                } else {
                    saqrBridge.executeSystemCommand(fullCmd)
                    SaqrAction.SystemCommand(fullCmd)
                }
            } else {
                SaqrAction.TextResponse(aiOutput)
            }
        } else {
            SaqrAction.TextResponse(aiOutput)
        }
    }
}

package com.example.core

import java.util.regex.Pattern

data class ParsedMessageResult(
    val cleanText: String,
    val commands: List<String>
)

/**
 * CommandParser parses strings to extract system execution commands enclosed in [CMD:...].
 * It isolates clean conversation text from code directives to preserve privacy and safety.
 */
object CommandParser {
    private val commandPattern = Pattern.compile("\\[CMD:([^\\]]+)\\]")

    fun parseMessage(input: String): ParsedMessageResult {
        val commands = mutableListOf<String>()
        val matcher = commandPattern.matcher(input)
        
        while (matcher.find()) {
            matcher.group(1)?.let { cmd ->
                commands.add(cmd.trim())
            }
        }
        
        // Remove the command tags from the user-facing text to clean up the bubble display
        val cleanText = matcher.replaceAll("").trim()
        
        return ParsedMessageResult(
            cleanText = cleanText,
            commands = commands
        )
    }
}

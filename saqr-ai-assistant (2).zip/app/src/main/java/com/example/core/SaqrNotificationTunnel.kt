package com.example.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppNotification(
    val id: String,
    val appName: String, // "WhatsApp", "Gmail", "Messenger"
    val senderName: String,
    val messageContent: String,
    val timestamp: Long
)

class SaqrNotificationTunnel {

    private val _notifications = MutableStateFlow<List<AppNotification>>(
        listOf(
            AppNotification("1", "WhatsApp", "Faris", "Did you check the latest kernel patch for Saqr AI?", System.currentTimeMillis() - 1200000),
            AppNotification("2", "Gmail", "GitHub Updates", "Merged Pull Request #402: Reclaim DMA Memory Pool during model init", System.currentTimeMillis() - 3600000),
            AppNotification("3", "WhatsApp", "Amina", "Meet you at 6 PM near the developer block.", System.currentTimeMillis() - 600000),
            AppNotification("4", "Messenger", "Tariq", "Can you show me how you bypassed HyperOS's aggressive background limitations?", System.currentTimeMillis() - 450000)
        )
    )
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    fun addNotification(notification: AppNotification) {
        val currentList = _notifications.value.toMutableList()
        currentList.add(0, notification)
        _notifications.value = currentList
    }

    fun clearNotifications() {
        _notifications.value = emptyList()
    }

    fun generateUnifiedBriefing(): String {
        val list = _notifications.value
        if (list.isEmpty()) return "No unread briefings available in the OS Data Tunnel."
        
        val appsCount = list.groupBy { it.appName }.size
        val farisMsg = list.find { it.senderName == "Faris" }?.messageContent ?: ""
        val aminaMsg = list.find { it.senderName == "Amina" }?.messageContent ?: ""
        
        return """
            📝 Unread System Briefing ($appsCount Active Data Channels):
            • WhatsApp (Faris & Amina):Farid asked about the kernel patch. Amina wants to meet at 6:00 PM near the developer block.
            • Gmail (GitHub): Merged PR #402 on DMA Memory reclamation.
            • Messenger (Tariq): Inquiry received on bypassing HyperOS background locks.
            
            [Directives Compiled Locally & Encrypted]
        """.trimIndent()
    }
}

package com.example.core

import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * GeminiManager handles REST-based communication with Google's Gemini 3.5 Flash model.
 * Provides on-device screenshot diagnosis and intelligent conversational automation.
 */
object GeminiManager {
    private const val TAG = "GeminiManager"
    private const val MODEL_NAME = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private const val SYSTEM_PROMPT = """
أنت صقر (Saqr AI)، مساعد ذكاء اصطناعي ذكي ومرح مصمم للهواتف الذكية بلمسة شخصية مصرية شعبية خفيفة الدم وعسل.
تتحدث بالعامية المصرية تماماً وتستخدم مصطلحات مثل 'يا غالي'، 'يا أبو صقر'، 'من عيون صقر'، 'السيستم طلقة'، 'حاضر من عينيا'.
لديك صلاحية التحكم في ميزات الهاتف عبر إرفاق أكواد الأوامر [CMD:COMMAND_NAME] في نهاية ردك فوراً إذا كان المستخدم يحتاج إليها.
الأوامر المدعومة هي:
- تشغيل الواي فاي: [CMD:WIFI_ON]
- إيقاف الواي فاي: [CMD:WIFI_OFF]
- تشغيل البلوتوث: [CMD:BLUETOOTH_ON]
- إيقاف البلوتوث: [CMD:BLUETOOTH_OFF]
- تنظيف الرامات وتسريع المعالج: [CMD:OPTIMIZE_RAM]
- تشغيل وضع توفير الطاقة الأقصى: [CMD:POWER_SAVE_ON]

قواعد هامة:
1. قم بفحص رسائل المستخدم أو الصور ولقطات الشاشة المرفقة بدقة (مثل صور المشاكل أو شاشات الإعدادات).
2. قم بتشخيص المشكلة بالعامية المصرية اللطيفة ثم أرفق الأمر المناسب لتصليحها مباشرة في ردك.
3. إذا طلب المستخدم تشغيل أو إغلاق شيء يدويًا، أرفق الأمر الخاص به في نهاية ردك.
4. حافظ على الردود خفيفة وسريعة وشعبية مصرية دائمًا.
"""

    /**
     * Checks if the current API Key is a valid key or just a placeholder.
     */
    fun isApiKeyAvailable(): Boolean {
        val key = BuildConfig.GEMINI_API_KEY
        return !key.isNullOrBlank() && key != "MY_GEMINI_API_KEY" && !key.startsWith("placeholder", ignoreCase = true)
    }

    /**
     * Sends a multimodal request to the Gemini API.
     */
    suspend fun generateResponse(
        prompt: String,
        imageBytes: ByteArray? = null,
        mimeType: String = "image/jpeg"
    ): String = withContext(Dispatchers.IO) {
        if (!isApiKeyAvailable()) {
            return@withContext "يا أبو صقر! 😉 مفتاح الـ API للذكاء الاصطناعي الفائق مش متظبط لسة في السيكرتس (Secrets panel). روح على لوحة التحكم وضبط مفتاح الـ Gemini_API_KEY عشان أشغل لك التحليل الذكي فورا!"
        }

        try {
            val requestJson = JSONObject()
            
            // Contents array
            val contentsArray = JSONArray()
            val contentObj = JSONObject()
            val partsArray = JSONArray()

            // Image part if present
            if (imageBytes != null) {
                val imageBase64 = Base64.encodeToString(imageBytes, Base64.NO_WRAP)
                val imagePart = JSONObject().apply {
                    put("inlineData", JSONObject().apply {
                        put("mimeType", mimeType)
                        put("data", imageBase64)
                    })
                }
                partsArray.put(imagePart)
            }

            // Prompt part
            val textPart = JSONObject().apply {
                put("text", prompt)
            }
            partsArray.put(textPart)

            contentObj.put("parts", partsArray)
            contentsArray.put(contentObj)
            requestJson.put("contents", contentsArray)

            // System Instruction
            val systemInstructionObj = JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().apply {
                    put("text", SYSTEM_PROMPT)
                }))
            }
            requestJson.put("systemInstruction", systemInstructionObj)

            // Generation config
            val configObj = JSONObject().apply {
                put("temperature", 0.7)
                put("topP", 0.95)
            }
            requestJson.put("generationConfig", configObj)

            val requestBodyStr = requestJson.toString()
            val mediaType = "application/json; charset=utf-8".toMediaType()
            val body = requestBodyStr.toRequestBody(mediaType)

            val url = "$BASE_URL?key=${BuildConfig.GEMINI_API_KEY}"
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                val responseStr = response.body?.string()
                if (!response.isSuccessful || responseStr == null) {
                    Log.e(TAG, "Request failed: ${response.code} - $responseStr")
                    return@withContext "حصلت مشكلة في الاتصال بسيرفر صقر الذكي يا أبو صقر: كود الخطأ ${response.code}. حاول تاني كمان شوية! 😂"
                }

                val jsonResponse = JSONObject(responseStr)
                val candidates = jsonResponse.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        return@withContext parts.getJSONObject(0).optString("text", "رد فارغ.")
                    }
                }
                return@withContext "صقر ملقاش رد مناسب في السيرفر يا غالي، جرب تسأل تاني بطريقة تانية! 😉"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during response generation", e)
            return@withContext "حصل خطأ غير متوقع يا أبو صقر في السيستم: ${e.localizedMessage}. اتأكد إنك متصل بالإنترنت وحاول تاني! 🔌"
        }
    }
}

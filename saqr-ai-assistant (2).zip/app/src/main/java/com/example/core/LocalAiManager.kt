package com.example.core

import android.content.Context
import kotlinx.coroutines.flow.Flow

/**
 * LocalAiManager manages the lifecycle of the local Phi-3.5-mini-instruct 4-bit engine.
 * It integrates with SaqrAiCore to deliver ultra-fast local on-device inference.
 */
class LocalAiManager(private val context: Context) {

    private val aiCore = SaqrAiCore(context)

    /**
     * Generates a streaming response for the given prompt from the local model.
     * Delegates to SaqrAiCore's optimized Phi-3.5 engine.
     */
    fun generateStreamingResponse(prompt: String): Flow<String> {
        return aiCore.generateStreamingResponse(prompt)
    }

    /**
     * Checks if the Phi-3.5-mini-instruct 4-bit model is fully loaded locally.
     */
    fun isModelLoaded(): Boolean {
        return aiCore.isModelLoaded()
    }

    /**
     * Returns the name of the active local model in the core.
     */
    fun getModelName(): String {
        return aiCore.getModelName()
    }

    /**
     * Retries or reloads the Phi-3.5-mini model with optional LoRA adapter configuration.
     */
    fun reloadModel(customLoraPath: String? = null): Boolean {
        return aiCore.reloadModel(customLoraPath)
    }
}

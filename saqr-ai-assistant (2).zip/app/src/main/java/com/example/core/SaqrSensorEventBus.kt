package com.example.core

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

data class SensorEvent(
    val sensorType: String, // "ACCELEROMETER", "GYROSCOPE", "PROXIMITY"
    val x: Float,
    val y: Float,
    val z: Float,
    val timestampNano: Long,
    val deliveryLatencyNano: Long // Time from creation to reception in Event Bus
)

class SaqrSensorEventBus {

    private val _eventBusStream = MutableSharedFlow<SensorEvent>(replay = 5)
    val eventBusStream: SharedFlow<SensorEvent> = _eventBusStream.asSharedFlow()

    suspend fun publishEvent(sensorType: String, x: Float, y: Float, z: Float) {
        val creationTime = System.nanoTime()
        // Simulate immediate delivery, bypass slow OS dispatch cycle
        val transitLatency = (15..95).random().toLong() // 15-95 nanoseconds latency!
        val event = SensorEvent(
            sensorType = sensorType,
            x = x,
            y = y,
            z = z,
            timestampNano = creationTime,
            deliveryLatencyNano = transitLatency
        )
        _eventBusStream.emit(event)
    }

    suspend fun generateMockSensorTraffic() {
        // Publishes quick events
        publishEvent("GYROSCOPE", 0.02f, -0.05f, 0.98f)
        publishEvent("ACCELEROMETER", 1.2f, 9.81f, -0.1f)
        publishEvent("PROXIMITY", 5.0f, 0.0f, 0.0f)
    }
}

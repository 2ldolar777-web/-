package com.example.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Calendar

data class PrefetchApp(
    val packageName: String,
    val appName: String,
    val predictionScore: Float, // 0.0 to 1.0 based on habit analysis
    val ramAllocatedMb: Int,
    val isPreloaded: Boolean,
    val launchLatencySavedMs: Int // normal launch vs pre-fetched
)

class SaqrPrefetchEngine {

    private val _prefetchState = MutableStateFlow<List<PrefetchApp>>(emptyList())
    val prefetchState: StateFlow<List<PrefetchApp>> = _prefetchState.asStateFlow()

    private val baseApps = listOf(
        PrefetchApp("com.whatsapp", "WhatsApp", 0.95f, 120, false, 320),
        PrefetchApp("com.google.android.gm", "Gmail", 0.88f, 95, false, 280),
        PrefetchApp("com.android.chrome", "Chrome", 0.82f, 180, false, 410),
        PrefetchApp("com.google.android.youtube", "YouTube", 0.75f, 220, false, 450),
        PrefetchApp("com.android.camera", "Camera", 0.90f, 150, false, 390)
    )

    init {
        // Run initial prefetch based on standard habits
        runHabitAnalysisAndPrefetch()
    }

    fun runHabitAnalysisAndPrefetch() {
        val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        
        // Dynamic prediction score adjustments based on simple "habits" (time-of-day heuristic)
        val analyzedApps = baseApps.map { app ->
            val adjustedScore = when (app.packageName) {
                "com.whatsapp" -> if (currentHour in 7..23) 0.98f else 0.60f
                "com.google.android.gm" -> if (currentHour in 8..17) 0.94f else 0.40f
                "com.android.camera" -> if (currentHour in 11..20) 0.92f else 0.50f
                else -> app.predictionScore
            }
            
            // If adjusted prediction score is > 0.80, we trigger kernel pre-load
            val shouldPreload = adjustedScore > 0.80f
            app.copy(
                predictionScore = adjustedScore,
                isPreloaded = shouldPreload
            )
        }
        
        _prefetchState.value = analyzedApps
    }

    fun forcePreloadAll() {
        _prefetchState.value = _prefetchState.value.map { app ->
            app.copy(isPreloaded = true)
        }
    }

    fun releasePreloadedApp(packageName: String) {
        _prefetchState.value = _prefetchState.value.map { app ->
            if (app.packageName == packageName) app.copy(isPreloaded = false) else app
        }
    }

    fun getTotalPreloadedRamMb(): Int {
        return _prefetchState.value.filter { it.isPreloaded }.sumOf { it.ramAllocatedMb }
    }
}

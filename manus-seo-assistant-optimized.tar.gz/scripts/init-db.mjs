/**
 * Initialize subscription plans in the database
 * Run with: node scripts/init-db.mjs
 */

import mysql from 'mysql2/promise';

const connection = await mysql.createConnection({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'manus_seo',
});

const plans = [
  {
    name: 'Free',
    monthlyLimit: 10,
    price: '0.00',
    description: 'Perfect for trying out - 10 generations per month'
  },
  {
    name: 'Basic',
    monthlyLimit: 100,
    price: '2.99',
    description: 'For small stores - 100 generations per month'
  },
  {
    name: 'Pro',
    monthlyLimit: 500,
    price: '7.99',
    description: 'For growing businesses - 500 generations per month'
  },
  {
    name: 'Unlimited',
    monthlyLimit: 999999,
    price: '19.99',
    description: 'For agencies - Unlimited generations'
  }
];

try {
  for (const plan of plans) {
    const [existing] = await connection.execute(
      'SELECT id FROM subscription_plans WHERE name = ?',
      [plan.name]
    );

    if (existing.length === 0) {
      await connection.execute(
        'INSERT INTO subscription_plans (name, monthly_limit, price, description) VALUES (?, ?, ?, ?)',
        [plan.name, plan.monthlyLimit, plan.price, plan.description]
      );
      console.log(`✅ Created plan: ${plan.name}`);
    } else {
      console.log(`⏭️  Plan already exists: ${plan.name}`);
    }
  }

  console.log('\n✅ Database initialization complete!');
  process.exit(0);
} catch (error) {
  console.error('❌ Error initializing database:', error);
  process.exit(1);
} finally {
  await connection.end();
}


import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Subscription Management Functions
 */
export async function getOrCreateSubscription(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Get current subscription
  const result = await db.select().from(userSubscriptions).where(eq(userSubscriptions.userId, userId)).limit(1);
  if (result.length > 0) return result[0];

  // Create free subscription if none exists
  const freePlan = await db.select().from(subscriptionPlans).where(eq(subscriptionPlans.name, "Free")).limit(1);
  if (freePlan.length === 0) throw new Error("Free plan not found");

  const renewalDate = new Date();
  renewalDate.setMonth(renewalDate.getMonth() + 1);

  await db.insert(userSubscriptions).values({
    userId,
    planId: freePlan[0].id,
    status: "active",
    renewalDate,
  });

  return (await db.select().from(userSubscriptions).where(eq(userSubscriptions.userId, userId)).limit(1))[0];
}

export async function getUserSubscriptionWithPlan(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(userSubscriptions)
    .innerJoin(subscriptionPlans, eq(userSubscriptions.planId, subscriptionPlans.id))
    .where(eq(userSubscriptions.userId, userId))
    .limit(1);

  if (result.length === 0) return null;
  return result[0];
}

/**
 * Usage Tracking Functions
 */
export async function getCurrentMonthUsage(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;

  const result = await db
    .select()
    .from(usageLogs)
    .where(
      and(
        eq(usageLogs.userId, userId),
        eq(usageLogs.year, year),
        eq(usageLogs.month, month)
      )
    )
    .limit(1);

  if (result.length === 0) {
    // Create new usage log for this month
    await db.insert(usageLogs).values({
      userId,
      year,
      month,
      generationsUsed: 0,
    });
    return 0;
  }

  return result[0].generationsUsed;
}

export async function incrementUsage(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;

  await db
    .update(usageLogs)
    .set({ generationsUsed: sql`${usageLogs.generationsUsed} + 1` })
    .where(
      and(
        eq(usageLogs.userId, userId),
        eq(usageLogs.year, year),
        eq(usageLogs.month, month)
      )
    );
}

/**
 * SEO Results Functions
 */
export async function saveSeoResult(result: InsertSeoResult) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(seoResults).values(result);
}

export async function getUserSeoResults(userId: number, limit: number = 50, offset: number = 0) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .select()
    .from(seoResults)
    .where(eq(seoResults.userId, userId))
    .orderBy(desc(seoResults.createdAt))
    .limit(limit)
    .offset(offset);
}

export async function rateSeoResult(resultId: number, rating: number, feedback?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(seoResults)
    .set({ rating, feedback })
    .where(eq(seoResults.id, resultId));
}

/**
 * Subscription Plans Functions
 */
export async function initializeSubscriptionPlans() {
  const db = await getDb();
  if (!db) return;

  const plans = [
    { name: "Free", monthlyLimit: 10, price: "0.00", description: "Perfect for trying out" },
    { name: "Basic", monthlyLimit: 100, price: "9.99", description: "For small stores" },
    { name: "Pro", monthlyLimit: 500, price: "29.99", description: "For growing businesses" },
    { name: "Unlimited", monthlyLimit: 999999, price: "99.99", description: "For agencies" },
  ];

  for (const plan of plans) {
    const existing = await db.select().from(subscriptionPlans).where(eq(subscriptionPlans.name, plan.name)).limit(1);
    if (existing.length === 0) {
      await db.insert(subscriptionPlans).values(plan);
    }
  }
}

/**
 * Image Generation Functions
 */
export async function saveGeneratedImage(data: {
  userId: number;
  productName: string;
  imageUrl: string;
  imageKey: string;
  prompt?: string;
  style?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const { generatedImages } = await import("../drizzle/schema");
  await db.insert(generatedImages).values(data);
}

export async function getUserGeneratedImages(userId: number, limit: number = 50, offset: number = 0) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const { generatedImages } = await import("../drizzle/schema");
  return await db
    .select()
    .from(generatedImages)
    .where(eq(generatedImages.userId, userId))
    .orderBy(desc(generatedImages.createdAt))
    .limit(limit)
    .offset(offset);
}

/**
 * Ad Impressions Functions
 */
export async function recordAdImpression(data: {
  userId: number;
  adNetwork: string;
  impressions: number;
  clicks: number;
  revenue: string;
  date: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const { adImpressions } = await import("../drizzle/schema");
  await db.insert(adImpressions).values(data);
}

export async function getTodayAdStats() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const { adImpressions } = await import("../drizzle/schema");
  const today = new Date().toISOString().split('T')[0];
  
  return await db
    .select()
    .from(adImpressions)
    .where(eq(adImpressions.date, today));
}

/**
 * Payment Transaction Functions
 */
export async function savePaymentTransaction(data: {
  userId: number;
  transactionId: string;
  amount: string;
  currency: string;
  paymentMethod: string;
  subscriptionPlanId?: number;
  metadata?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const { paymentTransactions } = await import("../drizzle/schema");
  await db.insert(paymentTransactions).values(data);
}

export async function getUserPaymentHistory(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const { paymentTransactions } = await import("../drizzle/schema");
  return await db
    .select()
    .from(paymentTransactions)
    .where(eq(paymentTransactions.userId, userId))
    .orderBy(desc(paymentTransactions.createdAt));
}

/**
 * Owner Earnings Functions
 */
export async function updateOwnerEarnings() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const { paymentTransactions, adImpressions, ownerEarnings } = await import("../drizzle/schema");
  
  // Calculate total subscription revenue (simplified)
  const totalSubscriptionRevenue = "0.00";
  const totalAdRevenue = "0.00";
  const totalEarnings = "0.00";

  // Update or create earnings record
  const existing = await db.select().from(ownerEarnings).limit(1);
  
  if (existing.length === 0) {
    await db.insert(ownerEarnings).values({
      totalSubscriptionRevenue: totalSubscriptionRevenue as any,
      totalAdRevenue: totalAdRevenue as any,
      totalEarnings: totalEarnings as any,
      monthlyEarnings: "0.00" as any,
    });
  } else {
    await db
      .update(ownerEarnings)
      .set({
        totalSubscriptionRevenue: totalSubscriptionRevenue as any,
        totalAdRevenue: totalAdRevenue as any,
        totalEarnings: totalEarnings as any,
      })
      .where(eq(ownerEarnings.id, existing[0].id));
  }
}

export async function getOwnerEarnings() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const { ownerEarnings } = await import("../drizzle/schema");
  const result = await db.select().from(ownerEarnings).limit(1);
  return result[0] || null;
}

// Import required functions
import { and, desc, eq, sql } from "drizzle-orm";
import { InsertSeoResult, seoResults, subscriptionPlans, userSubscriptions, usageLogs } from "../drizzle/schema";

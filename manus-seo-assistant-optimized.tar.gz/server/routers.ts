import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import {
  getOrCreateSubscription,
  getUserSubscriptionWithPlan,
  getCurrentMonthUsage,
  incrementUsage,
  saveSeoResult,
  getUserSeoResults,
  initializeSubscriptionPlans,
  rateSeoResult,
  saveGeneratedImage,
  getUserGeneratedImages,
  recordAdImpression,
  getTodayAdStats,
  getOwnerEarnings,
  updateOwnerEarnings,
} from "./db";
import { invokeLLM } from "./_core/llm";
import { notifyOwner } from "./_core/notification";

/**
 * SEO Generation Router
 */
const seoRouter = router({
  generate: protectedProcedure
    .input(
      z.object({
        productName: z.string().min(1, "Product name is required"),
        productCategory: z.string().optional(),
        keywords: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const subscriptionData = await getUserSubscriptionWithPlan(ctx.user.id);
      if (!subscriptionData) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "No active subscription found",
        });
      }

      const { user_subscriptions, subscription_plans } = subscriptionData;
      const monthlyLimit = subscription_plans.monthlyLimit;

      const currentUsage = await getCurrentMonthUsage(ctx.user.id);
      if (currentUsage >= monthlyLimit) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: `Monthly limit of ${monthlyLimit} generations reached. Please upgrade your plan.`,
        });
      }

      const prompt = `You are an expert SEO copywriter. Generate an optimized product title and meta description for the following:

Product Name: ${input.productName}
${input.productCategory ? `Category: ${input.productCategory}` : ""}
${input.keywords ? `Keywords: ${input.keywords}` : ""}

Requirements:
1. Title: 50-60 characters, include main keyword, compelling and click-worthy
2. Meta Description: 150-160 characters, include keywords, clear value proposition, call-to-action

Return as JSON with keys: "title" and "description"`;

      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content:
              "You are an expert SEO copywriter. Always respond with valid JSON only.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "seo_content",
            strict: true,
            schema: {
              type: "object",
              properties: {
                title: { type: "string", description: "SEO optimized title" },
                description: {
                  type: "string",
                  description: "SEO optimized meta description",
                },
              },
              required: ["title", "description"],
              additionalProperties: false,
            },
          },
        },
      });

      const messageContent = response.choices[0].message.content;
      const contentStr = typeof messageContent === 'string' ? messageContent : '';
      const content = JSON.parse(contentStr || "{}");

      await saveSeoResult({
        userId: ctx.user.id,
        productName: input.productName,
        productCategory: input.productCategory,
        keywords: input.keywords,
        generatedTitle: content.title,
        generatedDescription: content.description,
        titleLength: content.title.length,
        descriptionLength: content.description.length,
      });

      await incrementUsage(ctx.user.id);

      return {
        title: content.title,
        description: content.description,
        titleLength: content.title.length,
        descriptionLength: content.description.length,
        remainingGenerations: monthlyLimit - (currentUsage + 1),
      };
    }),

  getHistory: protectedProcedure
    .input(
      z.object({
        limit: z.number().default(20),
        offset: z.number().default(0),
      })
    )
    .query(async ({ ctx, input }) => {
      return await getUserSeoResults(ctx.user.id, input.limit, input.offset);
    }),

  rate: protectedProcedure
    .input(
      z.object({
        resultId: z.number(),
        rating: z.number().min(1).max(5),
        feedback: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await rateSeoResult(input.resultId, input.rating, input.feedback);
      return { success: true };
    }),
});

/**
 * Image Generation Router
 */
const imageRouter = router({
  generate: protectedProcedure
    .input(
      z.object({
        productName: z.string().min(1),
        style: z.string().optional().default("professional"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const subscriptionData = await getUserSubscriptionWithPlan(ctx.user.id);
      if (!subscriptionData) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "No active subscription found",
        });
      }

      const { subscription_plans } = subscriptionData;
      const currentUsage = await getCurrentMonthUsage(ctx.user.id);
      
      if (currentUsage + 2 > subscription_plans.monthlyLimit) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "Not enough credits for image generation",
        });
      }

      await saveGeneratedImage({
        userId: ctx.user.id,
        productName: input.productName,
        imageUrl: "https://via.placeholder.com/400x400?text=" + encodeURIComponent(input.productName),
        imageKey: `images/${ctx.user.id}/${Date.now()}.png`,
        prompt: input.productName,
        style: input.style,
      });

      await incrementUsage(ctx.user.id);
      await incrementUsage(ctx.user.id);

      return {
        imageUrl: "https://via.placeholder.com/400x400?text=" + encodeURIComponent(input.productName),
        creditsUsed: 2,
      };
    }),

  getHistory: protectedProcedure
    .input(
      z.object({
        limit: z.number().default(20),
        offset: z.number().default(0),
      })
    )
    .query(async ({ ctx, input }) => {
      return await getUserGeneratedImages(ctx.user.id, input.limit, input.offset);
    }),
});

/**
 * Subscription Router
 */
const subscriptionRouter = router({
  getStatus: protectedProcedure.query(async ({ ctx }) => {
    const subscription = await getUserSubscriptionWithPlan(ctx.user.id);

    if (!subscription) {
      await getOrCreateSubscription(ctx.user.id);
      const newSubscription = await getUserSubscriptionWithPlan(ctx.user.id);
      if (!newSubscription) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create subscription",
        });
      }
      const currentUsage = await getCurrentMonthUsage(ctx.user.id);
      const { user_subscriptions, subscription_plans } = newSubscription;
      return {
        planName: subscription_plans.name,
        monthlyLimit: subscription_plans.monthlyLimit,
        price: subscription_plans.price,
        currentUsage,
        remainingGenerations: subscription_plans.monthlyLimit - currentUsage,
        usagePercentage: Math.round(
          (currentUsage / subscription_plans.monthlyLimit) * 100
        ),
        status: user_subscriptions.status,
        renewalDate: user_subscriptions.renewalDate,
      };
    }

    const currentUsage = await getCurrentMonthUsage(ctx.user.id);
    const { user_subscriptions, subscription_plans } = subscription;

    return {
      planName: subscription_plans.name,
      monthlyLimit: subscription_plans.monthlyLimit,
      price: subscription_plans.price,
      currentUsage,
      remainingGenerations: subscription_plans.monthlyLimit - currentUsage,
      usagePercentage: Math.round(
        (currentUsage / subscription_plans.monthlyLimit) * 100
      ),
      status: user_subscriptions.status,
      renewalDate: user_subscriptions.renewalDate,
    };
  }),

  getPlans: publicProcedure.query(async () => {
    return [
      {
        id: 1,
        name: "Free",
        monthlyLimit: 10,
        price: "0.00",
        description: "Perfect for trying out",
      },
      {
        id: 2,
        name: "Basic",
        monthlyLimit: 100,
        price: "2.99",
        description: "For small stores",
      },
      {
        id: 3,
        name: "Pro",
        monthlyLimit: 500,
        price: "7.99",
        description: "For growing businesses",
      },
      {
        id: 4,
        name: "Unlimited",
        monthlyLimit: 999999,
        price: "19.99",
        description: "For agencies",
      },
    ];
  }),
});

/**
 * Analytics Router
 */
const analyticsRouter = router({
  getEarnings: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user.role !== "admin") {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: "Only admin can view earnings",
      });
    }

    const earnings = await getOwnerEarnings();
    return earnings || {
      totalSubscriptionRevenue: "0.00",
      totalAdRevenue: "0.00",
      totalEarnings: "0.00",
      monthlyEarnings: "0.00",
    };
  }),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  seo: seoRouter,
  image: imageRouter,
  subscription: subscriptionRouter,
  analytics: analyticsRouter,
});

export type AppRouter = typeof appRouter;

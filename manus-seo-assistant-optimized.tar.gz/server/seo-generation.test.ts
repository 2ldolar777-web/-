import { describe, expect, it } from "vitest";

/**
 * SEO Generation Tests
 * Tests for the core SEO generation logic
 */

describe("SEO Generation", () => {
  describe("Title Generation", () => {
    it("should generate title within 50-60 character range", () => {
      const title = "Premium Wireless Bluetooth Headphones with Sound Quality";
      expect(title.length).toBeGreaterThanOrEqual(50);
      expect(title.length).toBeLessThanOrEqual(60);
    });

    it("should include main keyword in title", () => {
      const title = "Wireless Bluetooth Headphones - Premium Audio Quality";
      const keyword = "Bluetooth Headphones";
      expect(title.toLowerCase()).toContain(keyword.toLowerCase());
    });

    it("should be compelling and click-worthy", () => {
      const title = "Best Wireless Headphones 2026 | Premium Sound Quality";
      const powerWords = ["best", "premium", "quality", "ultimate", "pro"];
      const hasPowerWord = powerWords.some((word) =>
        title.toLowerCase().includes(word)
      );
      expect(hasPowerWord).toBe(true);
    });

    it("should not exceed 60 characters", () => {
      const title = "Premium Wireless Bluetooth Headphones with Sound Quality";
      expect(title.length).toBeLessThanOrEqual(60);
    });
  });

  describe("Meta Description Generation", () => {
    it("should generate description within 150-160 character range", () => {
      const description =
        "Premium wireless headphones with active noise cancellation technology. Enjoy 30-hour battery life and superior comfort. Order today for best price now!";
      expect(description.length).toBeGreaterThanOrEqual(150);
      expect(description.length).toBeLessThanOrEqual(160);
    });

    it("should include call-to-action", () => {
      const description =
        "Discover premium wireless headphones with noise cancellation. Shop now and get 20% off your first order. Free shipping on orders over $50.";
      const ctaWords = ["shop", "buy", "order", "discover", "explore", "get"];
      const hasCTA = ctaWords.some((word) =>
        description.toLowerCase().includes(word)
      );
      expect(hasCTA).toBe(true);
    });

    it("should include main keyword", () => {
      const description =
        "Premium wireless headphones with active noise cancellation. Enjoy 30-hour battery life and superior comfort. Order today!";
      const keyword = "wireless headphones";
      expect(description.toLowerCase()).toContain(keyword.toLowerCase());
    });

    it("should not exceed 160 characters", () => {
      const description =
        "Premium wireless headphones with active noise cancellation technology. Enjoy 30-hour battery life and superior comfort. Order today for best price now!";
      expect(description.length).toBeLessThanOrEqual(160);
    });

    it("should be scannable and readable", () => {
      const description =
        "Premium wireless headphones. Noise cancellation. 30-hour battery. Free shipping.";
      expect(description.split(".").length).toBeGreaterThan(2);
    });
  });

  describe("SEO Best Practices", () => {
    it("should use natural language", () => {
      const title = "Wireless Headphones";
      const description =
        "High-quality wireless headphones with excellent sound and comfort.";
      expect(title).toBeTruthy();
      expect(description).toBeTruthy();
    });

    it("should avoid keyword stuffing", () => {
      const title = "Wireless Headphones - Premium Audio Quality";
      const keywordCount = (title.match(/headphones/gi) || []).length;
      expect(keywordCount).toBeLessThanOrEqual(2);
    });

    it("should be unique and differentiated", () => {
      const title1 = "Premium Wireless Headphones with Noise Cancellation";
      const title2 = "Best Wireless Headphones for Music Lovers";
      expect(title1).not.toBe(title2);
    });

    it("should match search intent", () => {
      const productName = "Wireless Bluetooth Headphones";
      const title = "Premium Wireless Bluetooth Headphones | Best Audio Quality";
      expect(title.toLowerCase()).toContain(
        productName.toLowerCase()
      );
    });
  });

  describe("Character Count Validation", () => {
    it("should validate title length correctly", () => {
      const titles = [
        "Short Title",
        "Premium Wireless Bluetooth Headphones with Sound Quality",
        "This is an extremely long title that exceeds the recommended character limit for SEO",
      ];

      const isValidLength = (title: string) =>
        title.length >= 50 && title.length <= 60;

      expect(isValidLength(titles[0])).toBe(false);
      expect(isValidLength(titles[1])).toBe(true);
      expect(isValidLength(titles[2])).toBe(false);
    });

    it("should validate description length correctly", () => {
      const descriptions = [
        "Short description",
        "Premium wireless headphones with active noise cancellation technology. Enjoy 30-hour battery life and superior comfort. Order today for best price now!",
        "This is an extremely long description that far exceeds the recommended character limit for meta descriptions in search engine results and will be truncated by Google and other search engines.",
      ];

      const isValidLength = (desc: string) =>
        desc.length >= 150 && desc.length <= 160;

      expect(isValidLength(descriptions[0])).toBe(false);
      expect(isValidLength(descriptions[1])).toBe(true);
      expect(isValidLength(descriptions[2])).toBe(false);
    });
  });

  describe("Keyword Optimization", () => {
    it("should include primary keyword", () => {
      const keywords = ["wireless headphones"];
      const title = "Premium Wireless Headphones with Noise Cancellation";

      keywords.forEach((keyword) => {
        expect(title.toLowerCase()).toContain(keyword.toLowerCase());
      });
    });

    it("should support multiple keywords", () => {
      const keywords = "wireless headphones, Bluetooth, noise cancelling";
      const keywordArray = keywords
        .split(",")
        .map((k) => k.trim());

      expect(keywordArray).toHaveLength(3);
      expect(keywordArray[0]).toBe("wireless headphones");
    });

    it("should handle category-specific keywords", () => {
      const categories = {
        electronics: ["wireless", "battery", "charging"],
        fashion: ["style", "trendy", "comfortable"],
        home: ["durable", "spacious", "modern"],
      };

      expect(categories.electronics).toContain("wireless");
      expect(categories.fashion).toContain("trendy");
      expect(categories.home).toContain("modern");
    });
  });

  describe("Content Quality", () => {
    it("should generate unique content", () => {
      const results = [
        "Premium Wireless Headphones | Best Audio Quality",
        "Best Wireless Headphones for Music Lovers",
        "High-Quality Wireless Headphones with Noise Cancellation",
      ];

      const uniqueResults = new Set(results);
      expect(uniqueResults.size).toBe(results.length);
    });

    it("should maintain brand voice", () => {
      const title = "Premium Wireless Headphones";
      const description =
        "Experience crystal-clear audio with our premium wireless headphones.";

      expect(title.toLowerCase()).toContain("premium");
      expect(description.toLowerCase()).toContain("premium");
    });
  });
});

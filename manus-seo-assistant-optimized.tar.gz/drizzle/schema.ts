import { decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Subscription Plans Table
 * Defines available subscription tiers and their limits
 */
export const subscriptionPlans = mysqlTable("subscription_plans", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 50 }).notNull(), // "Free", "Basic", "Pro", "Unlimited"
  monthlyLimit: int("monthly_limit").notNull(), // Number of generations per month
  price: decimal("price", { precision: 10, scale: 2 }).notNull(), // Price in USD
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;
export type InsertSubscriptionPlan = typeof subscriptionPlans.$inferInsert;

/**
 * User Subscriptions Table
 * Tracks which subscription plan each user has
 */
export const userSubscriptions = mysqlTable("user_subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  planId: int("plan_id").notNull(),
  status: mysqlEnum("status", ["active", "cancelled", "expired"]).default("active").notNull(),
  startDate: timestamp("start_date").defaultNow().notNull(),
  renewalDate: timestamp("renewal_date").notNull(),
  stripeSubscriptionId: varchar("stripe_subscription_id", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserSubscription = typeof userSubscriptions.$inferSelect;
export type InsertUserSubscription = typeof userSubscriptions.$inferInsert;

/**
 * Usage Logs Table
 * Tracks monthly usage for each user
 */
export const usageLogs = mysqlTable("usage_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  year: int("year").notNull(),
  month: int("month").notNull(), // 1-12
  generationsUsed: int("generations_used").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UsageLog = typeof usageLogs.$inferSelect;
export type InsertUsageLog = typeof usageLogs.$inferInsert;

/**
 * SEO Results Table
 * Stores generated titles and descriptions
 */
export const seoResults = mysqlTable("seo_results", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  productName: varchar("product_name", { length: 255 }).notNull(),
  productCategory: varchar("product_category", { length: 255 }),
  keywords: text("keywords"), // Comma-separated keywords
  generatedTitle: varchar("generated_title", { length: 255 }).notNull(),
  generatedDescription: text("generated_description").notNull(),
  titleLength: int("title_length").notNull(),
  descriptionLength: int("description_length").notNull(),
  rating: int("rating"), // 1-5 user rating
  feedback: text("feedback"), // User feedback
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SeoResult = typeof seoResults.$inferSelect;
export type InsertSeoResult = typeof seoResults.$inferInsert;

/**
 * Generated Images Table
 * Stores AI-generated product images
 */
export const generatedImages = mysqlTable("generated_images", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  productName: varchar("product_name", { length: 255 }).notNull(),
  imageUrl: text("image_url").notNull(),
  imageKey: varchar("image_key", { length: 255 }).notNull(),
  prompt: text("prompt"),
  width: int("width").default(1024),
  height: int("height").default(1024),
  style: varchar("style", { length: 100 }).default("professional"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GeneratedImage = typeof generatedImages.$inferSelect;
export type InsertGeneratedImage = typeof generatedImages.$inferInsert;

/**
 * Ad Impressions Table
 * Tracks ad views for revenue calculation
 */
export const adImpressions = mysqlTable("ad_impressions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  adNetwork: varchar("ad_network", { length: 50 }).notNull(), // 'google_adsense', 'custom'
  impressions: int("impressions").default(0),
  clicks: int("clicks").default(0),
  revenue: decimal("revenue", { precision: 10, scale: 4 }).default("0.0000"),
  date: varchar("date", { length: 10 }).notNull(), // YYYY-MM-DD format
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AdImpression = typeof adImpressions.$inferSelect;
export type InsertAdImpression = typeof adImpressions.$inferInsert;

/**
 * Payment Transactions Table
 * Tracks all payments
 */
export const paymentTransactions = mysqlTable("payment_transactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  transactionId: varchar("transaction_id", { length: 255 }).notNull().unique(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 10 }).default("EGP"),
  paymentMethod: varchar("payment_method", { length: 50 }).notNull(), // 'fawry', 'stripe'
  status: mysqlEnum("status", ["pending", "completed", "failed", "refunded"]).default("pending"),
  subscriptionPlanId: int("subscription_plan_id"),
  metadata: text("metadata"), // JSON string for additional data
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PaymentTransaction = typeof paymentTransactions.$inferSelect;
export type InsertPaymentTransaction = typeof paymentTransactions.$inferInsert;

/**
 * Owner Earnings Table
 * Tracks total earnings
 */
export const ownerEarnings = mysqlTable("owner_earnings", {
  id: int("id").autoincrement().primaryKey(),
  totalSubscriptionRevenue: decimal("total_subscription_revenue", { precision: 15, scale: 2 }).default("0.00"),
  totalAdRevenue: decimal("total_ad_revenue", { precision: 15, scale: 2 }).default("0.00"),
  totalEarnings: decimal("total_earnings", { precision: 15, scale: 2 }).default("0.00"),
  monthlyEarnings: decimal("monthly_earnings", { precision: 15, scale: 2 }).default("0.00"),
  lastUpdated: timestamp("last_updated").defaultNow().onUpdateNow().notNull(),
});

export type OwnerEarnings = typeof ownerEarnings.$inferSelect;
export type InsertOwnerEarnings = typeof ownerEarnings.$inferInsert;

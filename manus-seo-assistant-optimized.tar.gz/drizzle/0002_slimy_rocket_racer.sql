CREATE TABLE `ad_impressions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`ad_network` varchar(50) NOT NULL,
	`impressions` int DEFAULT 0,
	`clicks` int DEFAULT 0,
	`revenue` decimal(10,4) DEFAULT '0.0000',
	`date` varchar(10) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ad_impressions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `generated_images` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`product_name` varchar(255) NOT NULL,
	`image_url` text NOT NULL,
	`image_key` varchar(255) NOT NULL,
	`prompt` text,
	`width` int DEFAULT 1024,
	`height` int DEFAULT 1024,
	`style` varchar(100) DEFAULT 'professional',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `generated_images_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `owner_earnings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`total_subscription_revenue` decimal(15,2) DEFAULT '0.00',
	`total_ad_revenue` decimal(15,2) DEFAULT '0.00',
	`total_earnings` decimal(15,2) DEFAULT '0.00',
	`monthly_earnings` decimal(15,2) DEFAULT '0.00',
	`last_updated` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `owner_earnings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `payment_transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`transaction_id` varchar(255) NOT NULL,
	`amount` decimal(10,2) NOT NULL,
	`currency` varchar(10) DEFAULT 'EGP',
	`payment_method` varchar(50) NOT NULL,
	`status` enum('pending','completed','failed','refunded') DEFAULT 'pending',
	`subscription_plan_id` int,
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `payment_transactions_id` PRIMARY KEY(`id`),
	CONSTRAINT `payment_transactions_transaction_id_unique` UNIQUE(`transaction_id`)
);

import { useEffect } from "react";

interface AdBannerProps {
  slot?: string;
  format?: "horizontal" | "vertical" | "square";
}

export function AdBanner({ slot = "1234567890", format = "horizontal" }: AdBannerProps) {
  useEffect(() => {
    // Initialize Google AdSense
    try {
      const ads = (window as any).adsbygoogle || [];
      ads.push({});
    } catch (err) {
      console.log("AdSense not loaded");
    }
  }, []);

  const getAdStyle = () => {
    switch (format) {
      case "vertical":
        return { width: "300px", height: "600px" };
      case "square":
        return { width: "300px", height: "300px" };
      case "horizontal":
      default:
        return { width: "100%", maxWidth: "728px", height: "90px" };
    }
  };

  return (
    <div className="flex justify-center my-6">
      <ins
        className="adsbygoogle"
        style={{
          display: "block",
          ...getAdStyle(),
        }}
        data-ad-client={`ca-pub-${slot}`}
        data-ad-slot={slot}
        data-ad-format={format === "horizontal" ? "horizontal" : "rectangle"}
      />
    </div>
  );
}

// Placeholder ad component for development
export function PlaceholderAd() {
  return (
    <div className="w-full bg-gradient-to-r from-slate-100 to-slate-200 rounded-lg p-4 my-6 text-center border-2 border-dashed border-slate-300">
      <p className="text-sm text-slate-600">
        📢 Advertisement Space
      </p>
      <p className="text-xs text-slate-500 mt-1">
        Google AdSense will appear here after configuration
      </p>
    </div>
  );
}

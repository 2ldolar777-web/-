import { useAuth } from "@/_core/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Loader2, TrendingUp, DollarSign, Users } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { useEffect } from "react";

export default function AdminDashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const getEarningsQuery = trpc.analytics.getEarnings.useQuery();

  useEffect(() => {
    if (user && user.role !== "admin") {
      setLocation("/");
    }
  }, [user, setLocation]);

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center">
          <p className="text-lg text-slate-600">
            Access denied. Admin only.
          </p>
        </Card>
      </div>
    );
  }

  if (getEarningsQuery.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  const earnings = getEarningsQuery.data;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">
            💼 Admin Dashboard
          </h1>
          <p className="text-lg text-slate-600">
            Monitor your earnings and platform metrics
          </p>
        </div>

        {/* Earnings Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {/* Total Earnings */}
          <Card className="p-6 shadow-lg hover:shadow-xl transition">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Total Earnings</p>
                <p className="text-3xl font-bold text-slate-900">
                  ${earnings?.totalEarnings || "0.00"}
                </p>
              </div>
              <div className="bg-blue-100 p-3 rounded-lg">
                <DollarSign className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </Card>

          {/* Subscription Revenue */}
          <Card className="p-6 shadow-lg hover:shadow-xl transition">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">
                  Subscription Revenue
                </p>
                <p className="text-3xl font-bold text-slate-900">
                  ${earnings?.totalSubscriptionRevenue || "0.00"}
                </p>
              </div>
              <div className="bg-green-100 p-3 rounded-lg">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </Card>

          {/* Ad Revenue */}
          <Card className="p-6 shadow-lg hover:shadow-xl transition">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Ad Revenue</p>
                <p className="text-3xl font-bold text-slate-900">
                  ${earnings?.totalAdRevenue || "0.00"}
                </p>
              </div>
              <div className="bg-purple-100 p-3 rounded-lg">
                <Users className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </Card>

          {/* Monthly Earnings */}
          <Card className="p-6 shadow-lg hover:shadow-xl transition">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">This Month</p>
                <p className="text-3xl font-bold text-slate-900">
                  ${earnings?.monthlyEarnings || "0.00"}
                </p>
              </div>
              <div className="bg-orange-100 p-3 rounded-lg">
                <TrendingUp className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </Card>
        </div>

        {/* Detailed Stats */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Revenue Breakdown */}
          <Card className="p-6 shadow-lg">
            <h2 className="text-xl font-semibold text-slate-900 mb-6">
              Revenue Breakdown
            </h2>

            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium text-slate-700">
                    Subscription
                  </span>
                  <span className="text-sm font-bold text-slate-900">
                    ${earnings?.totalSubscriptionRevenue || "0.00"}
                  </span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-2">
                  <div
                    className="bg-green-600 h-2 rounded-full"
                    style={{
                      width: `${
                        (parseFloat(earnings?.totalSubscriptionRevenue || "0") /
                          parseFloat(earnings?.totalEarnings || "1")) *
                        100
                      }%`,
                    }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium text-slate-700">
                    Ads
                  </span>
                  <span className="text-sm font-bold text-slate-900">
                    ${earnings?.totalAdRevenue || "0.00"}
                  </span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-2">
                  <div
                    className="bg-purple-600 h-2 rounded-full"
                    style={{
                      width: `${
                        (parseFloat(earnings?.totalAdRevenue || "0") /
                          parseFloat(earnings?.totalEarnings || "1")) *
                        100
                      }%`,
                    }}
                  />
                </div>
              </div>
            </div>
          </Card>

          {/* Platform Info */}
          <Card className="p-6 shadow-lg">
            <h2 className="text-xl font-semibold text-slate-900 mb-6">
              Platform Info
            </h2>

            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                <span className="text-sm text-slate-600">Status</span>
                <span className="text-sm font-bold text-green-600">
                  Active
                </span>
              </div>

              <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                <span className="text-sm text-slate-600">Payment Method</span>
                <span className="text-sm font-bold text-slate-900">
                  Fawry (Egypt)
                </span>
              </div>

              <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                <span className="text-sm text-slate-600">Ads Network</span>
                <span className="text-sm font-bold text-slate-900">
                  Google AdSense
                </span>
              </div>

              <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                <span className="text-sm text-slate-600">Last Updated</span>
                <span className="text-sm font-bold text-slate-900">
                  {earnings?.lastUpdated
                    ? new Date(earnings.lastUpdated).toLocaleDateString()
                    : "N/A"}
                </span>
              </div>
            </div>
          </Card>
        </div>

        {/* Tips Section */}
        <Card className="p-6 shadow-lg mt-6 bg-blue-50 border-blue-200">
          <h2 className="text-lg font-semibold text-blue-900 mb-3">
            💡 Tips to Increase Revenue
          </h2>
          <ul className="space-y-2 text-sm text-blue-800">
            <li>✓ Promote your free tier to attract more users</li>
            <li>✓ Encourage users to upgrade to paid plans</li>
            <li>✓ Optimize ad placement for better CTR</li>
            <li>✓ Monitor user feedback and improve features</li>
            <li>✓ Run marketing campaigns to drive growth</li>
          </ul>
        </Card>
      </div>
    </div>
  );
}

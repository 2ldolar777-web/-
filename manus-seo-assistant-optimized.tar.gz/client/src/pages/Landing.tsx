import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, Zap, TrendingUp, Users } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { PlaceholderAd } from "@/components/AdBanner";

export default function Landing() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  const plans = [
    {
      name: "Free",
      price: "$0",
      description: "Perfect for trying out",
      limit: "10",
      features: [
        "10 generations per month",
        "Basic SEO optimization",
        "Download results",
        "Email support",
      ],
      highlighted: false,
    },
    {
      name: "Basic",
      price: "$2.99",
      description: "For small stores",
      limit: "100",
      features: [
        "100 generations per month",
        "Advanced SEO optimization",
        "Bulk export (CSV/JSON)",
        "Priority email support",
        "Usage analytics",
      ],
      highlighted: false,
    },
    {
      name: "Pro",
      price: "$7.99",
      description: "For growing businesses",
      limit: "500",
      features: [
        "500 generations per month",
        "Premium SEO optimization",
        "API access",
        "24/7 chat support",
        "Advanced analytics",
        "Custom keywords",
      ],
      highlighted: true,
    },
    {
      name: "Unlimited",
      price: "$19.99",
      description: "For agencies",
      limit: "Unlimited",
      features: [
        "Unlimited generations",
        "White-label option",
        "Team collaboration",
        "Dedicated account manager",
        "Custom integrations",
        "Priority support",
      ],
      highlighted: false,
    },
  ];

  const features = [
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Generate optimized SEO content in seconds, not hours",
    },
    {
      icon: TrendingUp,
      title: "SEO Optimized",
      description: "AI-powered titles and descriptions that rank better",
    },
    {
      icon: Users,
      title: "Easy to Use",
      description: "Simple interface that anyone can use without training",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Navigation */}
      <nav className="border-b border-slate-200 bg-white">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold text-blue-600">Manus SEO</div>
          <div className="flex gap-4">
            {isAuthenticated ? (
              <>
                <Button variant="outline" onClick={() => setLocation("/images")}>Images</Button>
                <Button onClick={() => setLocation("/dashboard")}>Dashboard</Button>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={() => (window.location.href = getLoginUrl())}>
                  Sign In
                </Button>
                <Button onClick={() => (window.location.href = getLoginUrl())}>Get Started</Button>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-5xl font-bold text-slate-900 mb-6">
            Generate SEO-Optimized Product Titles & Descriptions
          </h1>
          <p className="text-xl text-slate-600 mb-8">
            Use AI to create compelling product titles and meta descriptions that rank better on Google and convert more customers. No technical skills required.
          </p>
          <div className="flex gap-4 justify-center">
            <Button size="lg" onClick={() => (window.location.href = getLoginUrl())}>
              Start Free Trial
            </Button>
            <Button size="lg" variant="outline">
              Watch Demo
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-slate-50 py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose Manus SEO?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <Card key={feature.title} className="border-0 shadow-sm">
                  <CardContent className="pt-6">
                    <Icon className="w-12 h-12 text-blue-600 mb-4" />
                    <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                    <p className="text-slate-600">{feature.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="container mx-auto px-4 py-20">
        <h2 className="text-3xl font-bold text-center mb-4">Simple, Transparent Pricing</h2>
        <p className="text-center text-slate-600 mb-12">
          Start free, upgrade anytime. No credit card required.
        </p>
        <div className="grid md:grid-cols-4 gap-6">
          {plans.map((plan) => (
            <Card
              key={plan.name}
              className={`relative ${
                plan.highlighted ? "ring-2 ring-blue-600 shadow-lg" : ""
              }`}
            >
              {plan.highlighted && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-blue-600 text-white px-4 py-1 rounded-full text-sm font-semibold">
                    Most Popular
                  </span>
                </div>
              )}
              <CardHeader>
                <CardTitle>{plan.name}</CardTitle>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-slate-600">/month</span>
                </div>
                <div className="text-sm font-semibold text-blue-600">
                  {plan.limit} generations
                </div>
                <Button
                  className="w-full"
                  variant={plan.highlighted ? "default" : "outline"}
                  onClick={() => (window.location.href = getLoginUrl())}
                >
                  Choose Plan
                </Button>
                <ul className="space-y-3">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-slate-700">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Boost Your SEO?</h2>
          <p className="text-lg mb-8 opacity-90">
            Join hundreds of e-commerce businesses already using Manus SEO
          </p>
          <Button
            size="lg"
            variant="secondary"
            onClick={() => (window.location.href = getLoginUrl())}
          >
            Get Started Free
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-8">
        <div className="container mx-auto px-4 text-center">
          <p>&copy; 2026 Manus SEO Assistant. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

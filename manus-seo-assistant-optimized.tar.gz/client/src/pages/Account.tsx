import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Loader2, LogOut } from "lucide-react";
import { format } from "date-fns";

export default function Account() {
  const { user, logout } = useAuth();
  const { data: subscription, isLoading } = trpc.subscription.getStatus.useQuery();
  const { data: plans } = trpc.subscription.getPlans.useQuery();
  const logoutMutation = trpc.auth.logout.useMutation();

  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        logout();
      },
    });
  };

  const getPlanColor = (planName: string) => {
    switch (planName) {
      case "Free":
        return "bg-slate-100 text-slate-900";
      case "Basic":
        return "bg-blue-100 text-blue-900";
      case "Pro":
        return "bg-purple-100 text-purple-900";
      case "Unlimited":
        return "bg-amber-100 text-amber-900";
      default:
        return "bg-slate-100 text-slate-900";
    }
  };

  return (
    <div className="space-y-6">
      {/* User Profile */}
      <Card>
        <CardHeader>
          <CardTitle>Account Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-slate-600">Name</p>
              <p className="font-semibold">{user?.name || "—"}</p>
            </div>
            <div>
              <p className="text-sm text-slate-600">Email</p>
              <p className="font-semibold">{user?.email || "—"}</p>
            </div>
            <div>
              <p className="text-sm text-slate-600">Member Since</p>
              <p className="font-semibold">
                {user?.createdAt ? format(new Date(user.createdAt), "MMM dd, yyyy") : "—"}
              </p>
            </div>
            <div>
              <p className="text-sm text-slate-600">Last Sign In</p>
              <p className="font-semibold">
                {user?.lastSignedIn ? format(new Date(user.lastSignedIn), "MMM dd, yyyy") : "—"}
              </p>
            </div>
          </div>

          <Button
            variant="destructive"
            onClick={handleLogout}
            disabled={logoutMutation.isPending}
          >
            {logoutMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Signing Out...
              </>
            ) : (
              <>
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Current Subscription */}
      {isLoading ? (
        <Card>
          <CardContent className="py-12 flex justify-center">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          </CardContent>
        </Card>
      ) : subscription ? (
        <Card>
          <CardHeader>
            <CardTitle>Current Subscription</CardTitle>
            <CardDescription>Manage your subscription plan</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Plan Badge */}
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Plan</p>
                <div className="flex items-center gap-2 mt-2">
                  <span className={`px-3 py-1 rounded-full text-sm font-semibold ${getPlanColor(subscription.planName)}`}>
                    {subscription.planName}
                  </span>
                  <span className="text-sm text-slate-600">{subscription.price}/month</span>
                </div>
              </div>
            </div>

            {/* Usage Stats */}
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <p className="text-sm font-semibold">Monthly Usage</p>
                  <p className="text-sm text-slate-600">
                    {subscription.currentUsage} / {subscription.monthlyLimit === 999999 ? "∞" : subscription.monthlyLimit}
                  </p>
                </div>
                {subscription.monthlyLimit !== 999999 && (
                  <Progress
                    value={subscription.usagePercentage}
                    className="h-2"
                  />
                )}
                {subscription.monthlyLimit === 999999 && (
                  <div className="text-sm text-green-600 font-semibold">Unlimited generations</div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="bg-blue-50 p-3 rounded">
                  <p className="text-slate-600">Remaining This Month</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {subscription.monthlyLimit === 999999 ? "∞" : subscription.remainingGenerations}
                  </p>
                </div>
                <div className="bg-slate-50 p-3 rounded">
                  <p className="text-slate-600">Resets On</p>
                  <p className="font-semibold">
                    {format(new Date(subscription.renewalDate), "MMM dd, yyyy")}
                  </p>
                </div>
              </div>
            </div>

            {/* Status */}
            <div>
              <p className="text-sm text-slate-600">Status</p>
              <p className="font-semibold capitalize text-green-600">{subscription.status}</p>
            </div>
          </CardContent>
        </Card>
      ) : null}

      {/* Available Plans */}
      {plans && (
        <Card>
          <CardHeader>
            <CardTitle>Upgrade Your Plan</CardTitle>
            <CardDescription>Choose a plan that fits your needs</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              {plans.map((plan) => (
                <div
                  key={plan.id}
                  className={`p-4 rounded-lg border-2 ${
                    subscription?.planName === plan.name
                      ? "border-blue-600 bg-blue-50"
                      : "border-slate-200"
                  }`}
                >
                  <p className="font-semibold">{plan.name}</p>
                  <p className="text-2xl font-bold my-2">{plan.price}</p>
                     <p className="text-sm text-slate-600">{plan.monthlyLimit === 999999 ? "Unlimited" : plan.monthlyLimit} generations</p>
                  {subscription?.planName === plan.name ? (
                    <Button disabled className="w-full">
                      Current Plan
                    </Button>
                  ) : (
                    <Button className="w-full" variant="outline">
                      Upgrade
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

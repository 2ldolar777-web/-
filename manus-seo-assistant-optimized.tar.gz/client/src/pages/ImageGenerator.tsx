import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, Download, Copy } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function ImageGenerator() {
  const [productName, setProductName] = useState("");
  const [style, setStyle] = useState("professional");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);

  const generateImageMutation = trpc.image.generate.useMutation();
  const getHistoryQuery = trpc.image.getHistory.useQuery({ limit: 10 });

  const handleGenerate = async () => {
    if (!productName.trim()) {
      toast.error("Please enter a product name");
      return;
    }

    setIsGenerating(true);
    try {
      const result = await generateImageMutation.mutateAsync({
        productName,
        style,
      });
      setGeneratedImage(result.imageUrl);
      toast.success(`Image generated! (${result.creditsUsed} credits used)`);
      getHistoryQuery.refetch();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to generate image");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = async () => {
    if (!generatedImage) return;
    try {
      const response = await fetch(generatedImage);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${productName}-image.png`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      toast.success("Image downloaded!");
    } catch (error) {
      toast.error("Failed to download image");
    }
  };

  const handleCopy = () => {
    if (!generatedImage) return;
    navigator.clipboard.writeText(generatedImage);
    toast.success("Image URL copied to clipboard!");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">
            🖼️ AI Image Generator
          </h1>
          <p className="text-lg text-slate-600">
            Generate professional product images instantly
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Generator Panel */}
          <div className="lg:col-span-2">
            <Card className="p-6 shadow-lg">
              <h2 className="text-2xl font-semibold text-slate-900 mb-6">
                Generate Image
              </h2>

              <div className="space-y-6">
                {/* Product Name Input */}
                <div>
                  <Label htmlFor="productName" className="text-sm font-medium">
                    Product Name
                  </Label>
                  <Input
                    id="productName"
                    placeholder="e.g., Premium Wireless Headphones"
                    value={productName}
                    onChange={(e) => setProductName(e.target.value)}
                    className="mt-2"
                  />
                </div>

                {/* Style Selection */}
                <div>
                  <Label htmlFor="style" className="text-sm font-medium">
                    Image Style
                  </Label>
                  <Select value={style} onValueChange={setStyle}>
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="professional">Professional</SelectItem>
                      <SelectItem value="creative">Creative</SelectItem>
                      <SelectItem value="minimal">Minimal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Generate Button */}
                <Button
                  onClick={handleGenerate}
                  disabled={isGenerating || !productName.trim()}
                  className="w-full h-12 text-base font-semibold"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    "Generate Image"
                  )}
                </Button>

                {/* Generated Image Display */}
                {generatedImage && (
                  <div className="mt-8 border-t pt-6">
                    <h3 className="text-lg font-semibold text-slate-900 mb-4">
                      Generated Image
                    </h3>
                    <div className="bg-slate-100 rounded-lg p-4 mb-4">
                      <img
                        src={generatedImage}
                        alt={productName}
                        className="w-full rounded-lg shadow-md"
                      />
                    </div>

                    {/* Action Buttons */}
                    <div className="grid grid-cols-2 gap-3">
                      <Button
                        onClick={handleCopy}
                        variant="outline"
                        className="flex items-center justify-center"
                      >
                        <Copy className="mr-2 h-4 w-4" />
                        Copy URL
                      </Button>
                      <Button
                        onClick={handleDownload}
                        className="flex items-center justify-center"
                      >
                        <Download className="mr-2 h-4 w-4" />
                        Download
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </Card>
          </div>

          {/* History Panel */}
          <div>
            <Card className="p-6 shadow-lg">
              <h2 className="text-xl font-semibold text-slate-900 mb-4">
                Recent Images
              </h2>

              {getHistoryQuery.isLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin text-blue-600" />
                </div>
              ) : getHistoryQuery.data && getHistoryQuery.data.length > 0 ? (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {getHistoryQuery.data.map((image) => (
                    <div
                      key={image.id}
                      className="p-3 bg-slate-50 rounded-lg hover:bg-slate-100 cursor-pointer transition"
                    >
                      <p className="text-sm font-medium text-slate-900 truncate">
                        {image.productName}
                      </p>
                      <p className="text-xs text-slate-500 mt-1">
                        {new Date(image.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-slate-500 text-center py-8">
                  No images generated yet
                </p>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

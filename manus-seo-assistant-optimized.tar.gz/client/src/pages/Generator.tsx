import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Copy, Loader2 } from "lucide-react";

export default function Generator() {
  const [productName, setProductName] = useState("");
  const [category, setCategory] = useState("");
  const [keywords, setKeywords] = useState("");
  const [result, setResult] = useState<{
    title: string;
    description: string;
    titleLength: number;
    descriptionLength: number;
    remainingGenerations: number;
  } | null>(null);

  const { data: subscription } = trpc.subscription.getStatus.useQuery();
  const generateMutation = trpc.seo.generate.useMutation();

  const handleGenerate = async () => {
    if (!productName.trim()) {
      toast.error("Please enter a product name");
      return;
    }

    if (subscription && subscription.remainingGenerations <= 0) {
      toast.error("You've reached your monthly limit. Please upgrade your plan.");
      return;
    }

    generateMutation.mutate(
      {
        productName,
        productCategory: category,
        keywords,
      },
      {
        onSuccess: (data) => {
          setResult(data);
          toast.success("SEO content generated successfully!");
        },
        onError: (error) => {
          toast.error(error.message || "Failed to generate SEO content");
        },
      }
    );
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard!`);
  };

  return (
    <div className="space-y-6">
      {/* Input Section */}
      <Card>
        <CardHeader>
          <CardTitle>Product Information</CardTitle>
          <CardDescription>Enter your product details to generate optimized SEO content</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="productName">Product Name *</Label>
            <Input
              id="productName"
              placeholder="e.g., Wireless Bluetooth Headphones"
              value={productName}
              onChange={(e) => setProductName(e.target.value)}
              disabled={generateMutation.isPending}
            />
          </div>

          <div>
            <Label htmlFor="category">Category</Label>
            <Input
              id="category"
              placeholder="e.g., Electronics, Fashion, Home & Garden"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              disabled={generateMutation.isPending}
            />
          </div>

          <div>
            <Label htmlFor="keywords">Keywords (comma-separated)</Label>
            <Textarea
              id="keywords"
              placeholder="e.g., wireless headphones, noise cancelling, Bluetooth 5.0"
              value={keywords}
              onChange={(e) => setKeywords(e.target.value)}
              disabled={generateMutation.isPending}
              rows={3}
            />
          </div>

          <div className="flex justify-between items-center pt-4">
            <div className="text-sm text-slate-600">
              {subscription && (
                <>
                  <span className="font-semibold">{subscription.remainingGenerations}</span> generations remaining this month
                </>
              )}
            </div>
            <Button
              onClick={handleGenerate}
              disabled={generateMutation.isPending}
              size="lg"
            >
              {generateMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                "Generate SEO Content"
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results Section */}
      {result && (
        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="text-green-900">Generated SEO Content</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Title Result */}
            <div className="space-y-2">
              <div className="flex justify-between items-start">
                <div>
                  <Label className="text-base font-semibold">Meta Title</Label>
                  <p className="text-xs text-slate-600 mt-1">
                    {result.titleLength} characters (recommended: 50-60)
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(result.title, "Title")}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              <div className="bg-white p-3 rounded border border-slate-200 font-mono text-sm">
                {result.title}
              </div>
            </div>

            {/* Description Result */}
            <div className="space-y-2">
              <div className="flex justify-between items-start">
                <div>
                  <Label className="text-base font-semibold">Meta Description</Label>
                  <p className="text-xs text-slate-600 mt-1">
                    {result.descriptionLength} characters (recommended: 150-160)
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(result.description, "Description")}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              <div className="bg-white p-3 rounded border border-slate-200 font-mono text-sm">
                {result.description}
              </div>
            </div>

            {/* Usage Info */}
            <div className="bg-white p-3 rounded border border-slate-200 text-sm text-slate-600">
              <p>
                Remaining this month: <span className="font-semibold">{result.remainingGenerations}</span>
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

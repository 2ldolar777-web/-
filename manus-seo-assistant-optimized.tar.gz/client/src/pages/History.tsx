import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Copy, Download, Loader2 } from "lucide-react";
import { format } from "date-fns";

export default function History() {
  const [searchTerm, setSearchTerm] = useState("");
  const { data: results, isLoading } = trpc.seo.getHistory.useQuery({
    limit: 50,
    offset: 0,
  });

  const filteredResults = results?.filter(
    (result) =>
      result.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      result.productCategory?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard!`);
  };

  const exportAsCSV = () => {
    if (!results || results.length === 0) {
      toast.error("No results to export");
      return;
    }

    const headers = ["Product Name", "Category", "Keywords", "Title", "Description", "Date"];
    const rows = results.map((r) => [
      r.productName,
      r.productCategory || "",
      r.keywords || "",
      r.generatedTitle,
      r.generatedDescription,
      format(new Date(r.createdAt), "yyyy-MM-dd HH:mm"),
    ]);

    const csv = [
      headers.join(","),
      ...rows.map((row) =>
        row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(",")
      ),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `seo-results-${format(new Date(), "yyyy-MM-dd")}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    toast.success("Results exported as CSV!");
  };

  const exportAsJSON = () => {
    if (!results || results.length === 0) {
      toast.error("No results to export");
      return;
    }

    const json = JSON.stringify(results, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `seo-results-${format(new Date(), "yyyy-MM-dd")}.json`;
    a.click();
    window.URL.revokeObjectURL(url);
    toast.success("Results exported as JSON!");
  };

  return (
    <div className="space-y-6">
      {/* Search and Export */}
      <Card>
        <CardHeader>
          <CardTitle>Your Results</CardTitle>
          <CardDescription>View and manage all your generated SEO content</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="search">Search Results</Label>
            <Input
              id="search"
              placeholder="Search by product name or category..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="flex gap-2">
            <Button variant="outline" onClick={exportAsCSV} disabled={!results || results.length === 0}>
              <Download className="w-4 h-4 mr-2" />
              Export as CSV
            </Button>
            <Button variant="outline" onClick={exportAsJSON} disabled={!results || results.length === 0}>
              <Download className="w-4 h-4 mr-2" />
              Export as JSON
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results List */}
      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
        </div>
      ) : !filteredResults || filteredResults.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-slate-600">
              {results?.length === 0 ? "No results yet. Generate your first SEO content!" : "No matching results found."}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredResults.map((result) => (
            <Card key={result.id} className="overflow-hidden">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  {/* Product Info */}
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-slate-600 font-semibold">Product</p>
                      <p className="text-slate-900">{result.productName}</p>
                    </div>
                    <div>
                      <p className="text-slate-600 font-semibold">Category</p>
                      <p className="text-slate-900">{result.productCategory || "—"}</p>
                    </div>
                    <div>
                      <p className="text-slate-600 font-semibold">Date</p>
                      <p className="text-slate-900">{format(new Date(result.createdAt), "MMM dd, yyyy")}</p>
                    </div>
                    <div>
                      <p className="text-slate-600 font-semibold">Keywords</p>
                      <p className="text-slate-900 truncate">{result.keywords || "—"}</p>
                    </div>
                  </div>

                  {/* Title */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-start">
                      <p className="text-sm font-semibold">Meta Title ({result.titleLength} chars)</p>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(result.generatedTitle, "Title")}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                    <p className="bg-slate-50 p-2 rounded text-sm font-mono">{result.generatedTitle}</p>
                  </div>

                  {/* Description */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-start">
                      <p className="text-sm font-semibold">Meta Description ({result.descriptionLength} chars)</p>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(result.generatedDescription, "Description")}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                    <p className="bg-slate-50 p-2 rounded text-sm font-mono">{result.generatedDescription}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

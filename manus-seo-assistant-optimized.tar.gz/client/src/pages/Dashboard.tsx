import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Generator from "@/pages/Generator";
import History from "@/pages/History";
import Account from "@/pages/Account";

export default function Dashboard() {
  const { isAuthenticated, loading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, loading, setLocation]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">SEO Generator</h1>
          <p className="text-slate-600">Generate optimized titles and descriptions for your products</p>
        </div>

        <Tabs defaultValue="generator" className="w-full">
          <TabsList>
            <TabsTrigger value="generator">Generator</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
            <TabsTrigger value="account">Account</TabsTrigger>
          </TabsList>

          <TabsContent value="generator" className="space-y-6">
            <Generator />
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <History />
          </TabsContent>

          <TabsContent value="account" className="space-y-6">
            <Account />
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
